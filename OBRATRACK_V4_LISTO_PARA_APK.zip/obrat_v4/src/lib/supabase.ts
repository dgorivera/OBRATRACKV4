import { createClient } from "@supabase/supabase-js";

const url = import.meta.env.VITE_SUPABASE_URL as string | undefined;
const key = import.meta.env.VITE_SUPABASE_ANON_KEY as string | undefined;

// Sin variables de entorno la app abre en modo demostración (sin login real).
export const hasBackend = Boolean(url && key);
export const supabase = hasBackend ? createClient(url!, key!) : null;
