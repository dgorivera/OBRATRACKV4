un documento de especificaciones como si fueras el cliente y la IA fuera una empresa de desarrollo.

Para un proyecto profesional de visualización BIM y gestión de obras, estas son las indicaciones que deberías entregar.

Prompt Maestro

Quiero desarrollar una aplicación web progresiva (PWA) completamente responsive, compatible con computadores, tablets y teléfonos móviles.

La aplicación estará orientada a la gestión de proyectos de construcción utilizando modelos BIM, planificación de obra, control documental y seguimiento de actividades.

Quiero una arquitectura moderna, escalable y preparada para crecer con nuevos módulos.

1. Objetivo

Explicar qué hace la aplicación.

Ejemplo:

La aplicación permitirá visualizar modelos BIM, planificar proyectos, asignar tareas, controlar avances, administrar documentos técnicos, generar reportes y coordinar equipos de trabajo.

2. Usuarios

Definir tipos de usuarios.

Ejemplo

Administrador

Crea proyectos
Administra usuarios
Control total

Director de Proyecto

Gestiona planificación
Revisa avances
Aprueba documentos

Supervisor

Actualiza avances
Sube fotografías
Crea incidencias

Trabajador

Ve sus tareas
Marca actividades realizadas
Adjunta evidencias

Cliente

Sólo lectura
Ve avances
Descarga reportes
3. Inicio de sesión

Solicita:

Registro
Login
Recuperar contraseña
Verificación por correo
Roles
Permisos
4. Dashboard

Debe mostrar

Proyectos activos
Avance %
Actividades pendientes
Próximas reuniones
Últimas modificaciones
Alertas
Calendario
5. Módulo BIM

Aquí debes ser extremadamente específico.

Por ejemplo:

La aplicación debe poder visualizar modelos BIM en formato:

IFC
RVT (mediante conversión)
GLTF
OBJ

Debe permitir

✔ Orbitar

✔ Zoom

✔ Cortes

✔ Seleccionar elementos

✔ Mostrar propiedades

✔ Buscar elementos

✔ Ocultar categorías

✔ Colorear elementos

✔ Medir distancias

✔ Secciones

✔ Explosión del modelo

✔ Vista 3D

✔ Vista planta

✔ Vista isométrica

6. Gestión de proyectos

Cada proyecto debe tener

Nombre

Cliente

Ubicación

Estado

Fecha inicio

Fecha término

Profesionales

Modelo BIM asociado

Documentación

Cronograma

7. Planificación

Quiero un módulo tipo Microsoft Project.

Funciones

Carta Gantt
Dependencias
Ruta crítica
Hitos
Actividades
Recursos
Horas Hombre
Costos
Avance %
Drag and Drop
8. Kanban

Quiero un tablero Kanban con columnas

Pendiente

En ejecución

En revisión

Finalizado

9. Calendario

Calendario tipo Google Calendar

Debe mostrar

Reuniones

Inspecciones

Entregas

Actividades

Vencimientos

10. Gestión documental

Subir

PDF

DWG

RVT

IFC

Word

Excel

Fotos

Videos

Planos

Versionado

Historial

Comentarios

11. Inspecciones

Crear inspecciones

Agregar fotografías

Ubicación GPS

Observaciones

Prioridad

Responsable

Fecha límite

Estado

12. Incidencias

Crear incidencias

Asignar responsable

Subir imágenes

Relacionar con elemento BIM

Cerrar incidencia

Historial

13. Reportes

Generar automáticamente

PDF

Excel

Gráficos

Indicadores

Avance semanal

Avance mensual

Productividad

Horas hombre

Incidencias

14. Chat

Mensajería interna

Notificaciones

Comentarios

Menciones

Archivos

15. Notificaciones

Correo

Push

Aplicación

SMS (opcional)

16. Mapas

Visualizar ubicación de proyectos

Google Maps

OpenStreetMap

Coordenadas

17. Fotos

Galería

Antes

Después

Comparación

18. Panel administrativo

Usuarios

Roles

Permisos

Empresas

Clientes

Configuraciones

19. Diseño

Quiero una interfaz moderna inspirada en

Autodesk Construction Cloud

Procore

Notion

Linear

Monday

Figma

Minimalista

Oscuro y claro

Iconografía profesional

Animaciones suaves

20. Responsive

Debe funcionar perfectamente en

Desktop

Laptop

Tablet

iPad

Android

iPhone

21. Tecnologías

Solicita explícitamente:

Frontend

React
Next.js
TypeScript
TailwindCSS

Backend

Node.js
NestJS

Base de datos

PostgreSQL

ORM

Prisma

Autenticación

JWT
OAuth

Storage

S3

Realtime

Socket.io
22. Visualizador BIM

Pide usar

That Open Engine

o

IFC.js

o

xeokit

porque son las mejores tecnologías web para BIM.

23. Base de datos

Solicita que diseñe

Modelo ER

Tablas

Relaciones

Migraciones

API REST

API GraphQL

24. Arquitectura

Solicita

Arquitectura limpia

MVC

Repository Pattern

Services

DTO

Testing

Docker

CI/CD

25. Seguridad

JWT

HTTPS

Encriptación

Control de permisos

Logs

Auditoría

Backups

26. Escalabilidad

Debe estar preparada para agregar

IA

Gemelo Digital

Sensores IoT

Realidad Aumentada

Realidad Virtual

Drones

Gemini

OpenAI

Copilot BIM

27. Extras que marcarían la diferencia
Modo sin conexión (offline) con sincronización posterior.
Escaneo de códigos QR para identificar elementos en obra.
Integración con drones para registrar avances.
Comparación entre versiones de modelos BIM.
Visualización de cronogramas directamente sobre el modelo 3D (4D BIM).
Asociación de costos a elementos del modelo (5D BIM).
Captura de fotos georreferenciadas y anotaciones sobre el modelo.
Mi recomendación para tu proyecto

Conociendo el tipo de trabajos que has venido desarrollando (diseño, construcción, gestión territorial y proyectos BIM), no haría una aplicación únicamente para visualizar modelos BIM. La convertiría en una plataforma integral de gestión de proyectos, donde el modelo BIM sea el eje central y se conecte con la planificación, la documentación y el seguimiento en terreno.

Un concepto podría ser:

NODO Proyectos

"Una plataforma integral para planificar, visualizar y controlar proyectos de construcción y desarrollo territorial."

Esto permitiría incorporar módulos como:

🏗️ Visualizador BIM (3D, 4D y 5D).
📅 Planificación y Carta Gantt.
📂 Gestión documental.
👥 Administración de equipos y tareas.
📍 Seguimiento de avances en terreno.
📊 Panel de indicadores (KPIs).
🤖 Asistente con IA para consultar el modelo, resumir avances o generar informes.
📱 Aplicación responsive con acceso desde computador, tablet y celular.
🔌 Arquitectura preparada para integrarse con Autodesk, Revit, IFC, sensores IoT y otras herramientas del ecosistema BIM.

Con esta visión, la plataforma no sería solo un visor BIM, sino un sistema completo de gestión para oficinas de arquitectura, constructoras, inspecciones técnicas de obras (ITO), municipalidades y consultoras, con potencial para evolucionar como un producto SaaS comercial.