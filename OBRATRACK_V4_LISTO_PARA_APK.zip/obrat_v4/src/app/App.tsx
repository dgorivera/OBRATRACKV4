import { createContext, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import obraTrackLogo from "@/imports/obratrack-1-1.png";
import startupLogo from "@/imports/obratrack-logo.png";
import { ImageWithFallback } from "@/app/components/figma/ImageWithFallback";
import { AuthProvider, useAuth, ROL_LABEL, type Rol } from "@/app/auth/AuthContext";
import { AuthScreen } from "@/app/auth/AuthScreen";
import { supabase } from "@/lib/supabase";
import { AnimatePresence, motion, useReducedMotion } from "motion/react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import {
  LayoutDashboard, Box, ClipboardCheck,
  BarChart2, Bell, Search, Plus,
  Filter, MoreHorizontal, Upload, Download, Eye,
  TrendingUp, Users, Building2,
  Layers, ZoomIn, ZoomOut, RotateCcw, Maximize2,
  ChevronDown, ChevronLeft, ChevronRight, Move, Crosshair, X, List, Menu,
  Sliders, Shield, Globe, LogOut,
  PanelLeft, LayoutGrid, CheckCircle2, Trash2, FolderOpen, LoaderCircle,
} from "lucide-react";
import {
  BarChart, Bar, PieChart, Pie, Cell,
  XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line,
} from "recharts";

// ─── Types ─────────────────────────────────────────────────────────────────────
type Module =
  | "dashboard" | "bim" | "planning" | "control"
  | "reports" | "admin";

// Módulos visibles según el rol (la seguridad real la aplica la base de datos con RLS)
const TODOS: Module[] = ["dashboard", "bim", "planning", "control", "reports", "admin"];
const ACCESO: Record<Rol, Module[]> = {
  administrador: TODOS,
  director_proyecto: TODOS.filter((m) => m !== "admin"),
  supervisor: TODOS.filter((m) => m !== "admin"),
  trabajador: ["dashboard", "bim", "control"],
  cliente: ["dashboard", "bim", "planning", "reports"],
};

// ─── Mock Data ──────────────────────────────────────────────────────────────────
const projects = [
  { id: "P001", name: "Torre Residencial Bío-Bío", client: "Inmobiliaria Central SA", location: "Concepción, Chile", progress: 68, status: "active", startDate: "2024-03-01", endDate: "2025-08-30", team: 14 },
  { id: "P002", name: "Centro Comercial Antofagasta", client: "Retail Group SpA", location: "Antofagasta, Chile", progress: 34, status: "active", startDate: "2024-06-15", endDate: "2026-02-28", team: 22 },
  { id: "P003", name: "Hospital Regional Sur", client: "MINSAL", location: "Valdivia, Chile", progress: 12, status: "active", startDate: "2024-09-01", endDate: "2027-01-15", team: 38 },
  { id: "P004", name: "Parque Industrial Norte", client: "Zona Franca Iquique", location: "Iquique, Chile", progress: 91, status: "finishing", startDate: "2023-11-01", endDate: "2024-12-31", team: 9 },
];

const kpiData = [
  { label: "Avance General", value: "51%", change: "+3.2%", color: "#10b981" },
  { label: "Tareas Pendientes", value: "47", change: "-8", color: "#f59e0b" },
  { label: "Incidencias Abiertas", value: "12", change: "+3", color: "#ef4444" },
  { label: "Docs. en Revisión", value: "23", change: "+5", color: "#8b5cf6" },
  { label: "Miembros Activos", value: "83", change: "+2", color: "#06b6d4" },
];

const areaData = [
  { week: "S01", avance: 8, plan: 10 },
  { week: "S02", avance: 18, plan: 20 },
  { week: "S03", avance: 26, plan: 30 },
  { week: "S04", avance: 38, plan: 40 },
  { week: "S05", avance: 45, plan: 50 },
  { week: "S06", avance: 51, plan: 60 },
  { week: "S07", avance: 58, plan: 70 },
  { week: "S08", avance: 64, plan: 80 },
];

const pieData = [
  { name: "Estructura", value: 35, color: "#3b82f6" },
  { name: "Arquitectura", value: 28, color: "#10b981" },
  { name: "MMEESS", value: 22, color: "#f59e0b" },
  { name: "Terminaciones", value: 15, color: "#8b5cf6" },
];

const ganttTasks = [
  { id: 1, name: "Fundaciones", start: 0, duration: 8, progress: 100, color: "#10b981", responsible: "Jorge Muñoz" },
  { id: 2, name: "Estructura H.A. Piso 1–5", start: 6, duration: 12, progress: 85, color: "#3b82f6", responsible: "Karla Pérez" },
  { id: 3, name: "Estructura H.A. Piso 6–12", start: 16, duration: 14, progress: 40, color: "#3b82f6", responsible: "Karla Pérez" },
  { id: 4, name: "Albañilería Bloque A", start: 14, duration: 10, progress: 55, color: "#f59e0b", responsible: "Laura Torres" },
  { id: 5, name: "Instalaciones Eléctricas", start: 18, duration: 16, progress: 30, color: "#8b5cf6", responsible: "Rodrigo Vega" },
  { id: 6, name: "Instalaciones Sanitarias", start: 20, duration: 14, progress: 25, color: "#06b6d4", responsible: "Mario Silva" },
  { id: 7, name: "Terminaciones Int. Bloque A", start: 24, duration: 12, progress: 10, color: "#ef4444", responsible: "Patricia Rojas" },
  { id: 8, name: "Fachada y Exteriores", start: 28, duration: 8, progress: 0, color: "#f97316", responsible: "Ana Díaz" },
];

const TOTAL_WEEKS = 36;

const kanbanData: Record<string, KanbanItem[]> = {
  pendiente: [
    { id: 1, title: "Revisar planos As-Built Piso 8", priority: "alta", assignee: "KP", tag: "Estructura", dueDate: "2024-11-28" },
    { id: 2, title: "Aprobación materiales fachada", priority: "media", assignee: "LT", tag: "Arquitectura", dueDate: "2024-12-05" },
    { id: 3, title: "Informe mensual ITO", priority: "alta", assignee: "MS", tag: "Documentos", dueDate: "2024-11-30" },
  ],
  ejecucion: [
    { id: 4, title: "Hormigonado losa piso 9", priority: "critica", assignee: "JM", tag: "Estructura", dueDate: "2024-11-25" },
    { id: 5, title: "Instalación ventanas bloque C", priority: "media", assignee: "PR", tag: "Arquitectura", dueDate: "2024-12-10" },
    { id: 6, title: "Certificado subcontrato MMEESS", priority: "alta", assignee: "RV", tag: "Contratos", dueDate: "2024-11-29" },
  ],
  revision: [
    { id: 7, title: "Protocolo prueba estanque agua", priority: "alta", assignee: "MS", tag: "Sanitaria", dueDate: "2024-11-24" },
    { id: 8, title: "Carta Gantt actualizada sem 47", priority: "media", assignee: "KP", tag: "Planificación", dueDate: "2024-11-22" },
  ],
  finalizado: [
    { id: 9, title: "Fundaciones completadas", priority: "baja", assignee: "JM", tag: "Estructura", dueDate: "2024-10-15" },
    { id: 10, title: "Topografía replanteo", priority: "media", assignee: "AD", tag: "Terreno", dueDate: "2024-09-30" },
    { id: 11, title: "Estudio de suelos aprobado", priority: "alta", assignee: "LT", tag: "Terreno", dueDate: "2024-09-10" },
  ],
};

const calendarEvents = [
  { date: 22, title: "Reunión de coordinación semanal", time: "09:00", color: "#3b82f6" },
  { date: 22, title: "Entrega informe avance mensual", time: "18:00", color: "#10b981" },
  { date: 24, title: "Inspección ITO Piso 9", time: "10:30", color: "#f59e0b" },
  { date: 25, title: "Revisión BIM con arquitecto", time: "14:00", color: "#3b82f6" },
  { date: 28, title: "Hormigonado losa P10", time: "07:00", color: "#8b5cf6" },
  { date: 29, title: "Vencimiento contrato subcontrato", time: "23:59", color: "#ef4444" },
  { date: 5, title: "Entrega planos estructura R3", time: "17:00", color: "#10b981" },
];

const documents = [
  { id: 1, name: "Plano Arquitectura Piso 1-5 v3.2", type: "DWG", size: "18.4 MB", updatedAt: "2024-11-20", status: "aprobado", author: "K. Pérez", version: "3.2" },
  { id: 2, name: "Especificaciones Técnicas Estructura", type: "PDF", size: "4.1 MB", updatedAt: "2024-11-18", status: "en_revision", author: "J. Muñoz", version: "2.1" },
  { id: 3, name: "Modelo BIM Arquitectura", type: "IFC", size: "245 MB", updatedAt: "2024-11-15", status: "aprobado", author: "K. Pérez", version: "4.0" },
  { id: 4, name: "Presupuesto Actualizado Nov-2024", type: "XLSX", size: "2.8 MB", updatedAt: "2024-11-22", status: "aprobado", author: "L. Torres", version: "7.0" },
  { id: 5, name: "Fotografías Avance Semana 46", type: "ZIP", size: "1.2 GB", updatedAt: "2024-11-17", status: "aprobado", author: "P. Rojas", version: "1.0" },
  { id: 6, name: "Cronograma Proyecto General", type: "MPP", size: "8.3 MB", updatedAt: "2024-11-21", status: "en_revision", author: "M. Silva", version: "5.1" },
  { id: 7, name: "Informe Inspección ITO #23", type: "PDF", size: "3.6 MB", updatedAt: "2024-11-19", status: "pendiente", author: "R. Vega", version: "1.0" },
  { id: 8, name: "Manual Instalaciones Eléctricas", type: "PDF", size: "7.2 MB", updatedAt: "2024-11-10", status: "aprobado", author: "R. Vega", version: "1.2" },
];

const inspections = [
  { id: 1, title: "Inspección hormigonado losa piso 9", date: "2024-11-22", responsible: "J. Muñoz", priority: "alta", status: "abierta", location: "Piso 9 — Sector A", photos: 12 },
  { id: 2, title: "Revisión instalación ventanas bloque C", date: "2024-11-20", responsible: "P. Rojas", priority: "media", status: "en_proceso", location: "Bloque C — Fachada Norte", photos: 8 },
  { id: 3, title: "Control compactación área estacionamiento", date: "2024-11-18", responsible: "A. Díaz", priority: "baja", status: "cerrada", location: "Subterráneo -2", photos: 5 },
  { id: 4, title: "Verificación armadura muros caja escalera", date: "2024-11-15", responsible: "K. Pérez", priority: "critica", status: "cerrada", location: "Caja escalera principal", photos: 18 },
  { id: 5, title: "Inspección tuberías agua potable P3", date: "2024-11-24", responsible: "M. Silva", priority: "alta", status: "abierta", location: "Piso 3 — Shafts sanitarios", photos: 0 },
];

const issues = [
  { id: "INC-042", title: "Fisura en muro hormigón eje D4", description: "Fisura de 2.3mm en muro perimetral, requiere evaluación estructural", priority: "critica", status: "abierta", responsible: "K. Pérez", created: "2024-11-21", element: "MURO-D4-P7" },
  { id: "INC-041", title: "Desviación en aplome columna C8", description: "Columna presenta desviación de 12mm sobre tolerancia permitida", priority: "alta", status: "en_revision", responsible: "J. Muñoz", created: "2024-11-20", element: "COL-C8-P6" },
  { id: "INC-040", title: "Humedad en cielo falso oficinas", description: "Filtración de agua en cielo falso, probable origen en losa superior", priority: "media", status: "en_proceso", responsible: "M. Silva", created: "2024-11-18", element: "LOSA-P4-SB" },
  { id: "INC-039", title: "Materiales sin protocolo en bodega", description: "Acero de refuerzo sin certificado de calidad almacenado incorrectamente", priority: "alta", status: "cerrada", responsible: "L. Torres", created: "2024-11-15", element: "" },
  { id: "INC-038", title: "Corte suministro eléctrico zona sur", description: "Interrupción no programada afectó faena sur por 4 horas", priority: "baja", status: "cerrada", responsible: "R. Vega", created: "2024-11-14", element: "" },
];

const reportsWeekly = [
  { day: "Lun", avance: 2.1, meta: 2.5 },
  { day: "Mar", avance: 2.4, meta: 2.5 },
  { day: "Mié", avance: 1.8, meta: 2.5 },
  { day: "Jue", avance: 3.2, meta: 2.5 },
  { day: "Vie", avance: 2.7, meta: 2.5 },
  { day: "Sáb", avance: 1.5, meta: 1.5 },
];

const reportsHH = [
  { month: "Ago", real: 4820, plan: 5000 },
  { month: "Sep", real: 5140, plan: 5200 },
  { month: "Oct", real: 4980, plan: 5100 },
  { month: "Nov", real: 5260, plan: 5000 },
];

const activities = [
  { id: 1, user: "K. Pérez", action: "actualizó el modelo BIM", target: "Arquitectura v4.0", time: "hace 12 min", avatar: "KP" },
  { id: 2, user: "J. Muñoz", action: "cerró incidencia", target: "INC-039", time: "hace 34 min", avatar: "JM" },
  { id: 3, user: "M. Silva", action: "subió documento", target: "Plano Sanitario P3 v2.1", time: "hace 1 h", avatar: "MS" },
  { id: 4, user: "L. Torres", action: "actualizó avance al", target: "68% en Estructura", time: "hace 2 h", avatar: "LT" },
  { id: 5, user: "P. Rojas", action: "creó inspección", target: "Losa Piso 9", time: "hace 3 h", avatar: "PR" },
];

const adminUsers = [
  { id: 1, name: "ADMINISTRADOR", email: "d.rivera@nodo.cl", role: "Administrador", status: "activo", projects: 4, lastLogin: "hace 5 min" },
  { id: 2, name: "Karla Pérez", email: "k.perez@nodo.cl", role: "Director de Proyecto", status: "activo", projects: 2, lastLogin: "hace 1 h" },
  { id: 3, name: "Jorge Muñoz", email: "j.munoz@nodo.cl", role: "Supervisor", status: "activo", projects: 1, lastLogin: "hace 3 h" },
  { id: 4, name: "Laura Torres", email: "l.torres@nodo.cl", role: "Supervisor", status: "activo", projects: 3, lastLogin: "ayer" },
  { id: 5, name: "Mario Silva", email: "m.silva@nodo.cl", role: "Trabajador", status: "activo", projects: 2, lastLogin: "hace 2 h" },
  { id: 6, name: "Patricia Rojas", email: "p.rojas@nodo.cl", role: "Trabajador", status: "inactivo", projects: 1, lastLogin: "hace 3 días" },
  { id: 7, name: "Rodrigo Vega", email: "r.vega@nodo.cl", role: "Trabajador", status: "activo", projects: 2, lastLogin: "hace 6 h" },
  { id: 8, name: "Ana Díaz", email: "a.diaz@empresa.cl", role: "Cliente", status: "activo", projects: 1, lastLogin: "hace 1 día" },
];

// ─── Style helpers ──────────────────────────────────────────────────────────────
const priorityBadge: Record<string, string> = {
  critica: "bg-red-500/15 text-red-400 border border-red-500/30",
  alta: "bg-orange-500/15 text-orange-400 border border-orange-500/30",
  media: "bg-yellow-500/15 text-yellow-400 border border-yellow-500/30",
  baja: "bg-slate-500/15 text-slate-400 border border-slate-500/30",
};
const statusBadge: Record<string, string> = {
  abierta: "bg-red-500/15 text-red-400",
  en_proceso: "bg-blue-500/15 text-blue-400",
  en_revision: "bg-yellow-500/15 text-yellow-400",
  cerrada: "bg-emerald-500/15 text-emerald-400",
  aprobado: "bg-emerald-500/15 text-emerald-400",
  pendiente: "bg-slate-500/15 text-slate-400",
};
const fileTypeColor: Record<string, string> = {
  PDF: "#ef4444", DWG: "#3b82f6", IFC: "#8b5cf6",
  XLSX: "#10b981", ZIP: "#f59e0b", MPP: "#06b6d4",
};
const MONO = "'JetBrains Mono', monospace";
const EASE_OUT = [0.22, 1, 0.36, 1] as const;
const SPRING_SNAPPY = { type: "spring" as const, stiffness: 420, damping: 32 };
const STAGGER_CONTAINER = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.055, delayChildren: 0.04 } },
};
const STAGGER_ITEM = {
  hidden: { opacity: 0, y: 12, scale: 0.985 },
  visible: { opacity: 1, y: 0, scale: 1, transition: { duration: 0.38, ease: EASE_OUT } },
};

type PromptOptions = {
  title: string;
  label: string;
  placeholder?: string;
  confirmLabel?: string;
  onSubmit: (value: string) => void;
};

type UiContextValue = {
  notify: (message: string) => void;
  openDetails: (title: string, content: ReactNode) => void;
  openPrompt: (options: PromptOptions) => void;
  closeDialog: () => void;
};

const UiContext = createContext<UiContextValue | null>(null);

function useUI() {
  const context = useContext(UiContext);
  if (!context) throw new Error("useUI debe usarse dentro de UiProvider");
  return context;
}

function UiProvider({ children }: { children: ReactNode }) {
  const reduceMotion = useReducedMotion();
  const [toast, setToast] = useState<string | null>(null);
  const [details, setDetails] = useState<{ title: string; content: ReactNode } | null>(null);
  const [prompt, setPrompt] = useState<PromptOptions | null>(null);
  const [promptValue, setPromptValue] = useState("");

  const notify = (message: string) => {
    setToast(message);
    window.setTimeout(() => setToast((current) => current === message ? null : current), 2800);
  };

  const openPrompt = (options: PromptOptions) => {
    setPromptValue("");
    setPrompt(options);
  };

  const submitPrompt = () => {
    const value = promptValue.trim();
    if (!prompt || !value) return;
    prompt.onSubmit(value);
    setPrompt(null);
    setPromptValue("");
  };

  return (
    <UiContext.Provider value={{
      notify,
      openDetails: (title, content) => setDetails({ title, content }),
      openPrompt,
      closeDialog: () => { setDetails(null); setPrompt(null); },
    }}>
      {children}
      <AnimatePresence>
        {(details || prompt) && (
          <motion.div
            className="fixed inset-0 z-[100] flex items-center justify-center bg-black/70 p-4 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onMouseDown={() => { setDetails(null); setPrompt(null); }}
          >
            <motion.div
              role="dialog"
              aria-modal="true"
              aria-labelledby="app-dialog-title"
              className="w-full max-w-md rounded-xl border border-border bg-[#0f1623] p-5 shadow-2xl"
              initial={reduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.96, y: 12 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={reduceMotion ? { opacity: 0 } : { opacity: 0, scale: 0.96, y: 8 }}
              transition={reduceMotion ? { duration: 0.01 } : SPRING_SNAPPY}
              onMouseDown={(event) => event.stopPropagation()}
            >
              <div className="mb-4 flex items-center justify-between gap-4">
                <h2 id="app-dialog-title" className="text-sm font-semibold text-white">{details?.title ?? prompt?.title}</h2>
                <button
                  onClick={() => { setDetails(null); setPrompt(null); }}
                  className="rounded p-1 text-slate-500 transition-colors hover:bg-white/5 hover:text-white"
                  aria-label="Cerrar"
                >
                  <X size={16} />
                </button>
              </div>
              {details ? (
                <div className="text-sm leading-relaxed text-slate-300">{details.content}</div>
              ) : prompt ? (
                <form onSubmit={(event) => { event.preventDefault(); submitPrompt(); }}>
                  <label className="mb-1.5 block text-xs font-medium text-slate-400">{prompt.label}</label>
                  <input
                    autoFocus
                    value={promptValue}
                    onChange={(event) => setPromptValue(event.target.value)}
                    placeholder={prompt.placeholder}
                    className="w-full rounded-md border border-border bg-white/5 px-3 py-2.5 text-sm text-white outline-none transition focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20"
                  />
                  <div className="mt-5 flex justify-end gap-2">
                    <button type="button" onClick={() => setPrompt(null)} className="rounded-md border border-border px-3 py-2 text-xs text-slate-400 hover:bg-white/5">Cancelar</button>
                    <button type="submit" disabled={!promptValue.trim()} className="rounded-md bg-blue-600 px-3 py-2 text-xs font-semibold text-white hover:bg-blue-500 disabled:opacity-40">
                      {prompt.confirmLabel ?? "Guardar"}
                    </button>
                  </div>
                </form>
              ) : null}
            </motion.div>
          </motion.div>
        )}
        {toast && (
          <motion.div
            role="status"
            className="fixed bottom-5 left-1/2 z-[110] flex -translate-x-1/2 items-center gap-2 rounded-full border border-emerald-500/25 bg-[#101a25] px-4 py-2.5 text-xs font-medium text-emerald-300 shadow-xl"
            initial={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 18, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.96 }}
            transition={reduceMotion ? { duration: 0.01 } : SPRING_SNAPPY}
          >
            <CheckCircle2 size={14} />
            {toast}
          </motion.div>
        )}
      </AnimatePresence>
    </UiContext.Provider>
  );
}

function downloadText(filename: string, content: string, type = "text/csv;charset=utf-8") {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}

// ─── Sidebar ────────────────────────────────────────────────────────────────────
const navGroups = [
  { label: "Principal", items: [{ id: "dashboard", label: "Dashboard", icon: LayoutDashboard }] },
  { label: "BIM", items: [{ id: "bim", label: "Visor BIM", icon: Box }] },
  {
    label: "Gestión", items: [
      { id: "planning", label: "Planificación", icon: List },
    ],
  },
  {
    label: "Control", items: [
      { id: "control", label: "Inspecciones e incidencias", icon: ClipboardCheck },
    ],
  },
  {
    label: "Análisis", items: [
      { id: "reports", label: "Reportes", icon: BarChart2 },
    ],
  },
  { label: "Sistema", items: [{ id: "admin", label: "Administración", icon: Shield }] },
];

function Sidebar({
  active, onNavigate, collapsed, onToggle, mobileOpen, onMobileClose,
  permitidos, nombre, rolTexto, iniciales, onLogout,
}: {
  active: Module; onNavigate: (m: Module) => void; collapsed: boolean; onToggle: () => void;
  mobileOpen: boolean; onMobileClose: () => void;
  permitidos: Module[]; nombre: string; rolTexto: string; iniciales: string; onLogout: () => void;
}) {
  const handleNav = (m: Module) => {
    onNavigate(m);
    onMobileClose();
  };

  return (
    <>
      {/* Mobile overlay backdrop */}
      {mobileOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 md:hidden"
          onClick={onMobileClose}
        />
      )}
    <aside
      className={`flex flex-col border-r border-border transition-all duration-200 flex-shrink-0
        fixed inset-y-0 left-0 z-50 md:relative md:z-auto
        ${mobileOpen ? "translate-x-0" : "-translate-x-full"}
        md:translate-x-0
        ${collapsed ? "md:w-14" : "md:w-56"}
        w-64`}
      style={{ background: "#0b1019" }}
    >
      {/* Logo */}
      <div className="h-14 flex items-center px-3 border-b border-border gap-2.5 flex-shrink-0">
        <div className="w-8 h-8 rounded-lg overflow-hidden flex-shrink-0 border border-blue-500/20">
          <ImageWithFallback
            src={obraTrackLogo}
            alt="ObraTrack"
            className="w-full h-full object-cover"
          />
        </div>
        {!collapsed && (
          <div className="min-w-0">
            <div className="text-sm font-bold text-white leading-none tracking-wide">OBRATRACK</div>
            <div className="text-[10px] text-slate-500 leading-none mt-0.5" style={{ fontFamily: MONO }}>Proyectos v2.1</div>
          </div>
        )}
        <button onClick={onToggle} className="ml-auto text-slate-600 hover:text-slate-300 transition-colors p-1 rounded flex-shrink-0">
          <PanelLeft size={14} />
        </button>
      </div>

      {/* Project selector */}
      {!collapsed && (
        <div className="px-3 py-2.5 border-b border-border flex-shrink-0">
          <div className="flex items-center gap-2 px-2 py-1.5 rounded-md bg-white/5 hover:bg-white/8 cursor-pointer transition-colors">
            <div className="w-5 h-5 rounded bg-blue-600/70 flex items-center justify-center flex-shrink-0">
              <span className="text-[8px] text-white font-bold">TB</span>
            </div>
            <span className="text-xs text-slate-300 flex-1 truncate">Torre Bío-Bío</span>
            <ChevronDown size={11} className="text-slate-600 flex-shrink-0" />
          </div>
        </div>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-1.5">
        {navGroups.map((g) => ({ ...g, items: g.items.filter((i) => permitidos.includes(i.id as Module)) })).filter((g) => g.items.length > 0).map((group) => (
          <div key={group.label} className="mb-0.5">
            {!collapsed && (
              <div className="px-3 py-1.5 mt-1">
                <span className="text-[9px] font-semibold text-slate-700 uppercase tracking-widest" style={{ fontFamily: MONO }}>
                  {group.label}
                </span>
              </div>
            )}
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive = active === item.id;
              return (
                <motion.button
                  key={item.id}
                  onClick={() => handleNav(item.id as Module)}
                  title={collapsed ? item.label : undefined}
                  whileHover={collapsed ? { scale: 1.06 } : { x: 3 }}
                  whileTap={{ scale: 0.97 }}
                  className={`relative w-full flex items-center gap-2.5 px-3 py-2 text-left transition-colors ${
                    isActive
                      ? "text-blue-400 border-r-2 border-blue-500"
                      : "text-slate-500 hover:bg-white/4 hover:text-slate-200 border-r-2 border-transparent"
                  } ${collapsed ? "justify-center" : ""}`}
                >
                  {isActive && (
                    <motion.span
                      layoutId="active-sidebar-module"
                      className="absolute inset-0 z-0 bg-blue-600/12"
                      transition={SPRING_SNAPPY}
                    />
                  )}
                  <Icon size={14} className="relative z-10 flex-shrink-0" />
                  {!collapsed && <span className="relative z-10 text-xs font-medium">{item.label}</span>}
                </motion.button>
              );
            })}
          </div>
        ))}
      </nav>

      {/* User */}
      <div className="border-t border-border p-3 flex-shrink-0">
        <div className={`flex items-center gap-2 ${collapsed ? "justify-center" : ""}`}>
          <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-500 to-cyan-500 flex items-center justify-center flex-shrink-0">
            <span className="text-[10px] text-white font-bold">{iniciales}</span>
          </div>
          {!collapsed && (
            <>
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium text-slate-200 truncate">{nombre}</div>
                <div className="text-[10px] text-slate-600 truncate" style={{ fontFamily: MONO }}>{rolTexto}</div>
              </div>
              <button onClick={onLogout} title="Cerrar sesión" aria-label="Cerrar sesión" className="flex-shrink-0 p-1"><LogOut size={12} className="text-slate-500 hover:text-slate-200" /></button>
            </>
          )}
        </div>
      </div>
    </aside>
    </>
  );
}

// ─── TopBar ─────────────────────────────────────────────────────────────────────
const moduleTitles: Record<Module, string> = {
  dashboard: "Dashboard", bim: "Visor BIM", planning: "Planificación",
  control: "Inspecciones e incidencias", reports: "Reportes", admin: "Administración",
};

function TopBar({ module, onMenuToggle, onNavigate }: { module: Module; onMenuToggle: () => void; onNavigate: (module: Module) => void }) {
  const { notify, openPrompt } = useUI();
  const [query, setQuery] = useState("");
  const [showNotifications, setShowNotifications] = useState(false);
  const results = query.trim()
    ? Object.entries(moduleTitles).filter(([, title]) => title.toLowerCase().includes(query.toLowerCase())).slice(0, 5)
    : [];

  return (
    <header className="relative h-14 flex items-center gap-3 px-4 border-b border-border flex-shrink-0" style={{ background: "#0b1019" }}>
      {/* Hamburger — mobile only */}
      <button
        onClick={onMenuToggle}
        className="md:hidden p-1.5 text-slate-500 hover:text-slate-200 transition-colors flex-shrink-0"
      >
        <Menu size={18} />
      </button>

      <h1 className="text-sm font-semibold text-slate-100 flex-shrink-0 truncate">{moduleTitles[module]}</h1>

      {/* Search — hidden on small screens */}
      <div className="relative hidden flex-1 sm:block max-w-xs">
        <div className="flex items-center gap-2 bg-white/5 border border-border rounded-md px-3 py-1.5">
          <Search size={12} className="text-slate-600 flex-shrink-0" />
          <input
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Buscar módulos..."
            className="bg-transparent text-xs text-slate-300 placeholder:text-slate-600 outline-none flex-1 min-w-0"
          />
        </div>
        <AnimatePresence>
          {results.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -4 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -4 }}
              className="absolute left-0 right-0 top-10 z-50 overflow-hidden rounded-md border border-border bg-[#111827] shadow-xl"
            >
              {results.map(([id, title]) => (
                <button
                  key={id}
                  onClick={() => { onNavigate(id as Module); setQuery(""); }}
                  className="flex w-full items-center gap-2 px-3 py-2 text-left text-xs text-slate-300 transition-colors hover:bg-blue-600/15 hover:text-white"
                >
                  <Search size={11} className="text-blue-400" />
                  {title}
                </button>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="flex items-center gap-2 ml-auto flex-shrink-0">
        <button onClick={() => setShowNotifications((value) => !value)} className="relative p-1.5 text-slate-600 hover:text-slate-300 transition-colors" aria-label="Notificaciones">
          <Bell size={15} />
          <span className="absolute top-0.5 right-0.5 w-1.5 h-1.5 bg-red-500 rounded-full" />
        </button>
        <button
          onClick={() => openPrompt({
            title: "Creación rápida",
            label: "Nombre del elemento",
            placeholder: "Ej. Revisión semanal",
            confirmLabel: "Crear",
            onSubmit: (value) => notify(`“${value}” fue creado correctamente`),
          })}
          className="flex items-center gap-1.5 text-[11px] text-white bg-blue-600 hover:bg-blue-700 transition-colors px-3 py-1.5 rounded-md"
        >
          <Plus size={12} />
          <span className="hidden sm:inline">Nuevo</span>
        </button>
      </div>
      <AnimatePresence>
        {showNotifications && (
          <motion.div
            initial={{ opacity: 0, y: -6, scale: 0.98 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -6, scale: 0.98 }}
            className="absolute right-4 top-12 z-50 w-72 overflow-hidden rounded-lg border border-border bg-[#111827] shadow-2xl"
          >
            <div className="flex items-center justify-between border-b border-border px-3 py-2.5">
              <span className="text-xs font-semibold text-white">Notificaciones</span>
              <button onClick={() => { setShowNotifications(false); notify("Notificaciones marcadas como leídas"); }} className="text-[10px] text-blue-400 hover:text-blue-300">Marcar leídas</button>
            </div>
            {[
              ["Documento aprobado", "Plano Arquitectura v3.2", "hace 12 min"],
              ["Inspección pendiente", "Losa piso 9", "hace 1 h"],
              ["Nueva incidencia", "INC-042 · Prioridad crítica", "hace 3 h"],
            ].map(([title, detail, time]) => (
              <button key={title} onClick={() => setShowNotifications(false)} className="block w-full border-b border-border/40 px-3 py-2.5 text-left hover:bg-white/5">
                <span className="block text-[11px] font-medium text-slate-200">{title}</span>
                <span className="block text-[10px] text-slate-500">{detail} · {time}</span>
              </button>
            ))}
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

// ─── Dashboard ───────────────────────────────────────────────────────────────────
function DashboardProgressChart() {
  const width = 720;
  const height = 180;
  const plot = { left: 34, right: 12, top: 8, bottom: 26 };
  const plotWidth = width - plot.left - plot.right;
  const plotHeight = height - plot.top - plot.bottom;
  const x = (index: number) => plot.left + (index * plotWidth) / (areaData.length - 1);
  const y = (value: number) => plot.top + ((100 - value) / 100) * plotHeight;
  const planPoints = areaData.map((point, index) => `${x(index)},${y(point.plan)}`).join(" ");
  const progressPoints = areaData.map((point, index) => `${x(index)},${y(point.avance)}`).join(" ");
  const progressArea = `${plot.left},${plot.top + plotHeight} ${progressPoints} ${x(areaData.length - 1)},${plot.top + plotHeight}`;
  const gridValues = [0, 25, 50, 75, 100];

  return (
    <div className="h-[180px] w-full">
      <svg
        viewBox={`0 0 ${width} ${height}`}
        preserveAspectRatio="none"
        className="h-full w-full overflow-visible"
        role="img"
        aria-label="Avance real comparado con el plan semanal"
      >
        <defs>
          <linearGradient id="dashboard-progress-fill" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#3b82f6" stopOpacity="0.28" />
            <stop offset="100%" stopColor="#3b82f6" stopOpacity="0.02" />
          </linearGradient>
        </defs>

        {gridValues.map((value) => (
          <g key={`dashboard-grid-${value}`}>
            <line
              x1={plot.left}
              x2={width - plot.right}
              y1={y(value)}
              y2={y(value)}
              stroke="rgba(255,255,255,0.05)"
              strokeDasharray="3 3"
            />
            <text
              x={plot.left - 7}
              y={y(value) + 3}
              textAnchor="end"
              fill="#475569"
              fontSize="9"
              fontFamily={MONO}
            >
              {value}%
            </text>
          </g>
        ))}

        <motion.polygon
          points={progressArea}
          fill="url(#dashboard-progress-fill)"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, delay: 0.25, ease: EASE_OUT }}
        />
        <motion.polyline
          points={planPoints}
          fill="none"
          stroke="#10b981"
          strokeWidth="1.5"
          strokeDasharray="5 4"
          vectorEffect="non-scaling-stroke"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{ duration: 0.85, delay: 0.12, ease: EASE_OUT }}
        />
        <motion.polyline
          points={progressPoints}
          fill="none"
          stroke="#3b82f6"
          strokeWidth="2"
          vectorEffect="non-scaling-stroke"
          initial={{ pathLength: 0, opacity: 0 }}
          animate={{ pathLength: 1, opacity: 1 }}
          transition={{ duration: 0.9, ease: EASE_OUT }}
        />

        {areaData.map((point, index) => (
          <g key={`dashboard-point-${point.week}`}>
            <motion.circle
              cx={x(index)}
              cy={y(point.avance)}
              r="3"
              fill="#3b82f6"
              stroke="#dbeafe"
              strokeWidth="1.5"
              vectorEffect="non-scaling-stroke"
              initial={{ scale: 0, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ delay: 0.12 + index * 0.07, ...SPRING_SNAPPY }}
            >
              <title>{`${point.week}: avance ${point.avance}%, plan ${point.plan}%`}</title>
            </motion.circle>
            <text
              x={x(index)}
              y={height - 7}
              textAnchor="middle"
              fill="#475569"
              fontSize="9"
              fontFamily={MONO}
            >
              {point.week}
            </text>
          </g>
        ))}
      </svg>
    </div>
  );
}

function Dashboard() {
  return (
    <div className="p-3 sm:p-5 space-y-4">
      {/* KPIs */}
      <motion.div
        variants={STAGGER_CONTAINER}
        initial="hidden"
        animate="visible"
        className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3"
      >
        {kpiData.map((kpi) => (
          <motion.div variants={STAGGER_ITEM} key={kpi.label} whileHover={{ y: -4, borderColor: "rgba(59,130,246,0.28)" }} className="rounded-lg border border-border p-3.5" style={{ background: "#0f1623" }}>
            <div className="text-[9px] text-slate-600 mb-1.5 uppercase tracking-widest" style={{ fontFamily: MONO }}>{kpi.label}</div>
            <div className="text-2xl font-bold text-white leading-none">{kpi.value}</div>
            <div className="flex items-center gap-1 mt-1.5" style={{ fontFamily: MONO }}>
              <TrendingUp size={9} style={{ color: kpi.color }} />
              <span className="text-[10px]" style={{ color: kpi.color }}>{kpi.change}</span>
            </div>
          </motion.div>
        ))}
      </motion.div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="lg:col-span-2 rounded-lg border border-border p-4" style={{ background: "#0f1623" }}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-xs font-semibold text-slate-200">Avance vs Plan</h3>
              <p className="text-[10px] text-slate-600 mt-0.5" style={{ fontFamily: MONO }}>Torre Residencial Bío-Bío</p>
            </div>
            <span className="text-[10px] text-slate-500 bg-white/5 px-2 py-1 rounded border border-border" style={{ fontFamily: MONO }}>SEM 44/52</span>
          </div>
          <DashboardProgressChart />
        </div>

        <div className="rounded-lg border border-border p-4" style={{ background: "#0f1623" }}>
          <h3 className="text-xs font-semibold text-slate-200 mb-0.5">Avance por Especialidad</h3>
          <p className="text-[10px] text-slate-600 mb-3" style={{ fontFamily: MONO }}>Desglose actual</p>
          <div className="flex h-[130px] items-center justify-center" role="img" aria-label="Avance por especialidad">
            <div
              className="relative h-28 w-28 rounded-full"
              style={{ background: "conic-gradient(#3b82f6 0% 35%, #10b981 35% 63%, #f59e0b 63% 85%, #8b5cf6 85% 100%)" }}
            >
              <div className="absolute inset-[18px] rounded-full border border-white/5" style={{ background: "#0f1623" }} />
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <span className="text-lg font-bold text-slate-100">51%</span>
                <span className="text-[8px] uppercase tracking-widest text-slate-600" style={{ fontFamily: MONO }}>general</span>
              </div>
            </div>
          </div>
          <div className="space-y-1.5 mt-2">
            {pieData.map((d) => (
              <div key={d.name} className="flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: d.color }} />
                  <span className="text-[11px] text-slate-400">{d.name}</span>
                </div>
                <span className="text-[10px] text-slate-300" style={{ fontFamily: MONO }}>{d.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Activity */}
      <div className="rounded-lg border border-border p-4" style={{ background: "#0f1623" }}>
          <h3 className="text-xs font-semibold text-slate-200 mb-3">Actividad Reciente</h3>
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
            {activities.map((a) => (
              <div key={a.id} className="flex items-start gap-2.5">
                <div className="w-6 h-6 rounded-full bg-slate-800 border border-border flex items-center justify-center flex-shrink-0 mt-0.5">
                  <span className="text-[8px] font-bold text-slate-400">{a.avatar}</span>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-[11px] text-slate-400 leading-relaxed">
                    <span className="font-semibold text-slate-200">{a.user}</span>{" "}
                    {a.action}{" "}
                    <span className="text-blue-400">{a.target}</span>
                  </div>
                  <div className="text-[9px] text-slate-700 mt-0.5" style={{ fontFamily: MONO }}>{a.time}</div>
                </div>
              </div>
            ))}
          </div>
      </div>
    </div>
  );
}

// ─── BIM Viewer ──────────────────────────────────────────────────────────────────
type BimPlan = {
  id: string;
  name: string;
  storagePath: string;
  type: string;
  size: number;
  status: "listo" | "procesando" | "error" | "local";
  createdAt: string;
  localUrl?: string;
};

function BIMViewer() {
  const { perfil, demo } = useAuth();
  const { notify, openDetails, closeDialog } = useUI();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedEl, setSelectedEl] = useState<string | null>(null);
  const [showProps, setShowProps] = useState(true);
  const [activeTool, setActiveTool] = useState("Orbitar");
  const [viewMode, setViewMode] = useState("3D");
  const [zoom, setZoom] = useState(1);
  const [plans, setPlans] = useState<BimPlan[]>([]);
  const [selectedPlanId, setSelectedPlanId] = useState<string | null>(null);
  const [showPlans, setShowPlans] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [obraId, setObraId] = useState<string | null>(null);
  const selectedPlan = plans.find((plan) => plan.id === selectedPlanId) ?? null;

  useEffect(() => {
    if (!supabase || demo || !perfil) return;
    let active = true;
    const loadPlans = async () => {
      const { data: obras, error: obraError } = await supabase
        .from("obras")
        .select("id,nombre")
        .order("creada_en", { ascending: true })
        .limit(1);
      if (!active || obraError || !obras?.[0]) return;
      const currentObraId = obras[0].id as string;
      setObraId(currentObraId);
      const { data } = await supabase
        .from("planos_bim")
        .select("id,nombre,storage_path,tipo,tamano,estado,creado_en")
        .eq("obra_id", currentObraId)
        .order("creado_en", { ascending: false });
      if (!active || !data) return;
      const loadedPlans = data.map((plan) => ({
        id: String(plan.id),
        name: String(plan.nombre),
        storagePath: String(plan.storage_path),
        type: String(plan.tipo),
        size: Number(plan.tamano),
        status: plan.estado as BimPlan["status"],
        createdAt: String(plan.creado_en),
      }));
      setPlans(loadedPlans);
      setSelectedPlanId((current) => current ?? loadedPlans[0]?.id ?? null);
    };
    void loadPlans();
    return () => { active = false; };
  }, [demo, perfil]);

  const handlePlanUpload = async (file: File) => {
    const extension = file.name.split(".").pop()?.toLowerCase() ?? "";
    const allowedExtensions = ["ifc", "dwg", "dxf", "pdf", "rvt", "nwd", "nwc"];
    if (!allowedExtensions.includes(extension)) {
      notify("Formato no admitido. Usa IFC, DWG, DXF, PDF, RVT, NWD o NWC");
      return;
    }
    if (file.size > 100 * 1024 * 1024) {
      notify("El plano supera el límite de 100 MB");
      return;
    }

    setUploading(true);
    try {
      if (!supabase || demo) {
        const localPlan: BimPlan = {
          id: `local-${Date.now()}`,
          name: file.name,
          storagePath: "",
          type: extension.toUpperCase(),
          size: file.size,
          status: "local",
          createdAt: new Date().toISOString(),
          localUrl: URL.createObjectURL(file),
        };
        setPlans((current) => [localPlan, ...current]);
        setSelectedPlanId(localPlan.id);
        setShowPlans(true);
        notify("Plano cargado para esta sesión de demostración");
        return;
      }

      if (!obraId) throw new Error("Primero debes crear o tener acceso a una obra.");
      const safeName = file.name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-zA-Z0-9._-]/g, "-");
      const storagePath = `${obraId}/${crypto.randomUUID()}-${safeName}`;
      const { error: uploadError } = await supabase.storage
        .from("planos-bim")
        .upload(storagePath, file, { cacheControl: "3600", upsert: false, contentType: file.type || "application/octet-stream" });
      if (uploadError) throw uploadError;

      const { data, error: metadataError } = await supabase
        .from("planos_bim")
        .insert({
          obra_id: obraId,
          nombre: file.name,
          storage_path: storagePath,
          tipo: extension.toUpperCase(),
          tamano: file.size,
          estado: "listo",
          subido_por: perfil.id,
        })
        .select("id,nombre,storage_path,tipo,tamano,estado,creado_en")
        .single();
      if (metadataError) {
        await supabase.storage.from("planos-bim").remove([storagePath]);
        throw metadataError;
      }

      const uploadedPlan: BimPlan = {
        id: String(data.id),
        name: String(data.nombre),
        storagePath: String(data.storage_path),
        type: String(data.tipo),
        size: Number(data.tamano),
        status: data.estado as BimPlan["status"],
        createdAt: String(data.creado_en),
      };
      setPlans((current) => [uploadedPlan, ...current]);
      setSelectedPlanId(uploadedPlan.id);
      setShowPlans(true);
      notify("Plano cargado y guardado en la plataforma");
    } catch (error) {
      notify(error instanceof Error ? error.message : "No se pudo cargar el plano");
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  const openPlan = async (plan: BimPlan) => {
    if (plan.localUrl) {
      window.open(plan.localUrl, "_blank", "noopener,noreferrer");
      return;
    }
    if (!supabase) return;
    const planWindow = window.open("about:blank", "_blank");
    const { data, error } = await supabase.storage.from("planos-bim").createSignedUrl(plan.storagePath, 60);
    if (error || !data?.signedUrl) {
      planWindow?.close();
      notify("No se pudo abrir el plano");
      return;
    }
    if (planWindow) {
      planWindow.opener = null;
      planWindow.location.href = data.signedUrl;
    } else {
      window.location.href = data.signedUrl;
    }
  };

  const deletePlan = async (plan: BimPlan) => {
    if (plan.localUrl) {
      URL.revokeObjectURL(plan.localUrl);
    } else if (supabase) {
      const { error: storageError } = await supabase.storage.from("planos-bim").remove([plan.storagePath]);
      if (storageError) {
        notify(storageError.message);
        return;
      }
      const { error: metadataError } = await supabase.from("planos_bim").delete().eq("id", plan.id);
      if (metadataError) {
        notify(metadataError.message);
        return;
      }
    }
    setPlans((current) => current.filter((item) => item.id !== plan.id));
    setSelectedPlanId((current) => current === plan.id ? null : current);
    closeDialog();
    notify("Plano eliminado");
  };

  const props = selectedEl
    ? { "ID Elemento": selectedEl, "Tipo": "Muro H.A.", "Material": "HA-25/B/20/IIa", "Espesor": "200 mm", "Altura": "3.000 m", "Área": "12.6 m²", "Piso": "Nivel 7", "Estado": "Construido", "ITO": "Aprobado" }
    : null;

  const toolbarTools = [
    { icon: Move, label: "Orbitar" },
    { icon: ZoomIn, label: "Zoom In" },
    { icon: ZoomOut, label: "Zoom Out" },
    { icon: Crosshair, label: "Seleccionar" },
    { icon: Maximize2, label: "Extents" },
    { icon: RotateCcw, label: "Reset" },
    { icon: Layers, label: "Capas" },
    { icon: Sliders, label: "Secciones" },
  ];

  return (
    <div className="flex overflow-hidden" style={{ height: "calc(100vh - 112px)" }}>
      {/* Left toolbar */}
      <div className="w-10 flex flex-col items-center gap-0.5 p-1.5 border-r border-border flex-shrink-0" style={{ background: "#0b1019" }}>
        {toolbarTools.map(({ icon: Icon, label }) => (
          <button
            key={label}
            title={label}
            onClick={() => {
              setActiveTool(label);
              if (label === "Zoom In") setZoom((value) => Math.min(1.5, value + 0.1));
              if (label === "Zoom Out") setZoom((value) => Math.max(0.7, value - 0.1));
              if (label === "Reset" || label === "Extents") { setZoom(1); setSelectedEl(null); }
              if (label === "Capas") setShowProps(true);
            }}
            className={`w-7 h-7 flex items-center justify-center rounded transition-colors ${activeTool === label ? "bg-blue-600/20 text-blue-400" : "text-slate-600 hover:text-slate-200 hover:bg-white/8"}`}
          >
            <Icon size={13} />
          </button>
        ))}
      </div>

      {/* Viewport */}
      <div className="flex-1 relative overflow-hidden" style={{ background: "#060a12" }}>
        {/* View mode */}
        <div className="absolute top-3 left-3 z-20 flex flex-wrap gap-1">
          {["3D", "Planta", "ISO"].map((m) => (
            <button onClick={() => setViewMode(m)} key={m} className={`px-2.5 py-1 rounded text-[9px] uppercase tracking-wider transition-colors border ${m === viewMode ? "bg-blue-600 text-white border-blue-600" : "bg-black/50 text-slate-500 border-border hover:text-slate-300"}`} style={{ fontFamily: MONO }}>
              {m}
            </button>
          ))}
          <span className="mx-1 h-6 w-px bg-border" />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploading}
            className="flex items-center gap-1.5 rounded border border-blue-500/40 bg-blue-600 px-2.5 py-1 text-[9px] font-semibold uppercase tracking-wider text-white transition-colors hover:bg-blue-500 disabled:cursor-wait disabled:opacity-60"
            style={{ fontFamily: MONO }}
          >
            {uploading ? <LoaderCircle size={11} className="animate-spin" /> : <Upload size={11} />}
            {uploading ? "Cargando" : "Cargar plano"}
          </button>
          <button
            onClick={() => setShowPlans((value) => !value)}
            className={`flex items-center gap-1.5 rounded border px-2.5 py-1 text-[9px] uppercase tracking-wider transition-colors ${showPlans ? "border-cyan-500/40 bg-cyan-500/15 text-cyan-300" : "border-border bg-black/50 text-slate-400 hover:text-white"}`}
            style={{ fontFamily: MONO }}
          >
            <FolderOpen size={11} />
            Planos ({plans.length})
          </button>
          <input
            ref={fileInputRef}
            type="file"
            className="hidden"
            accept=".ifc,.dwg,.dxf,.pdf,.rvt,.nwd,.nwc"
            onChange={(event) => {
              const file = event.target.files?.[0];
              if (file) void handlePlanUpload(file);
            }}
          />
        </div>

        <AnimatePresence>
          {showPlans && (
            <motion.div
              initial={{ opacity: 0, y: -6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              className="absolute left-3 top-12 z-30 w-[min(22rem,calc(100%-1.5rem))] overflow-hidden rounded-lg border border-border bg-[#0b1019]/95 shadow-2xl backdrop-blur-md"
            >
              <div className="flex items-center justify-between border-b border-border px-3 py-2.5">
                <div>
                  <div className="text-xs font-semibold text-white">Planos del proyecto</div>
                  <div className="text-[9px] text-slate-600">IFC, DWG, DXF, PDF, RVT, NWD y NWC · máx. 100 MB</div>
                </div>
                <button onClick={() => fileInputRef.current?.click()} className="rounded p-1.5 text-blue-400 hover:bg-blue-500/10" title="Cargar otro plano"><Plus size={14} /></button>
              </div>
              <div className="max-h-72 overflow-y-auto p-2">
                {plans.length === 0 ? (
                  <button onClick={() => fileInputRef.current?.click()} className="flex w-full flex-col items-center rounded-md border border-dashed border-border px-4 py-8 text-slate-600 hover:border-blue-500/30 hover:text-blue-400">
                    <Upload size={20} className="mb-2" />
                    <span className="text-xs font-medium">Carga tu primer plano</span>
                  </button>
                ) : plans.map((plan) => (
                  <div
                    key={plan.id}
                    className={`mb-1 flex items-center gap-2 rounded-md border p-2 transition-colors ${selectedPlanId === plan.id ? "border-blue-500/35 bg-blue-600/10" : "border-transparent hover:bg-white/5"}`}
                  >
                    <button onClick={() => { setSelectedPlanId(plan.id); setShowPlans(false); }} className="flex min-w-0 flex-1 items-center gap-2 text-left">
                      <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded bg-blue-500/10 text-[8px] font-bold text-blue-400" style={{ fontFamily: MONO }}>{plan.type}</div>
                      <div className="min-w-0">
                        <div className="truncate text-[11px] font-medium text-slate-200">{plan.name}</div>
                        <div className="text-[9px] text-slate-600">{(plan.size / 1024 / 1024).toFixed(1)} MB · {plan.status === "local" ? "solo esta sesión" : "guardado"}</div>
                      </div>
                    </button>
                    <button onClick={() => void openPlan(plan)} title="Abrir plano" className="rounded p-1.5 text-slate-600 hover:bg-white/5 hover:text-white"><Eye size={12} /></button>
                    <button
                      onClick={() => openDetails("Eliminar plano", <div><p className="mb-4">Se eliminará “{plan.name}” de la plataforma.</p><button onClick={() => void deletePlan(plan)} className="rounded bg-red-600 px-3 py-2 text-xs font-semibold text-white hover:bg-red-500">Eliminar definitivamente</button></div>)}
                      title="Eliminar plano"
                      className="rounded p-1.5 text-slate-600 hover:bg-red-500/10 hover:text-red-400"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Info overlay */}
        <div className="absolute top-3 right-3 z-10 hidden space-y-1.5 sm:block">
          {[
            { label: "PLANO ACTIVO", val: selectedPlan?.name ?? "Modelo de ejemplo" },
            { label: "FORMATO", val: selectedPlan?.type ?? "IFC 4.0" },
          ].map((s) => (
            <div key={s.label} className="bg-black/70 border border-border rounded px-2.5 py-1.5 backdrop-blur-sm" style={{ fontFamily: MONO }}>
              <div className="text-[8px] text-slate-700">{s.label}</div>
              <div className="max-w-40 truncate text-[10px] text-slate-300" title={s.val}>{s.val}</div>
            </div>
          ))}
        </div>

        {/* SVG BIM wireframe */}
        <svg viewBox="0 0 900 580" className="w-full h-full transition-transform duration-300" style={{ transform: `scale(${zoom})` }} onClick={() => setSelectedEl(null)}>
          <defs>
            <radialGradient id="bgG" cx="50%" cy="50%" r="60%">
              <stop offset="0%" stopColor="#0d1a2e" />
              <stop offset="100%" stopColor="#060a12" />
            </radialGradient>
            <filter id="glow">
              <feGaussianBlur stdDeviation="2.5" result="blur" />
              <feMerge><feMergeNode in="blur" /><feMergeNode in="SourceGraphic" /></feMerge>
            </filter>
          </defs>
          <rect width="900" height="580" fill="url(#bgG)" />

          {/* Floor grid */}
          {Array.from({ length: 24 }).map((_, i) => (
            <line key={`fh${i}`} x1={150 + i * 30} y1="440" x2={200 + i * 30} y2="360" stroke="rgba(59,130,246,0.07)" strokeWidth="0.5" />
          ))}
          {Array.from({ length: 14 }).map((_, i) => (
            <line key={`fv${i}`} x1="150" y1={360 + i * 6} x2="850" y2={360 + i * 6} stroke="rgba(59,130,246,0.05)" strokeWidth="0.5" />
          ))}

          <AnimatePresence mode="wait">
            {viewMode === "Planta" ? (
              <motion.g key="floor-plan" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
                <rect x="165" y="70" width="570" height="400" rx="2" fill="rgba(8,18,32,0.88)" stroke="#3b82f6" strokeWidth="2" />
                <rect x="185" y="90" width="530" height="360" fill="none" stroke="rgba(148,163,184,0.65)" strokeWidth="5" />
                <line x1="360" y1="90" x2="360" y2="450" stroke="rgba(148,163,184,0.55)" strokeWidth="4" />
                <line x1="540" y1="90" x2="540" y2="450" stroke="rgba(148,163,184,0.55)" strokeWidth="4" />
                <line x1="185" y1="250" x2="715" y2="250" stroke="rgba(148,163,184,0.55)" strokeWidth="4" />
                <rect x="380" y="270" width="140" height="160" fill="rgba(59,130,246,0.08)" stroke="#22d3ee" strokeWidth="1.5" />
                <rect
                  x="190"
                  y="95"
                  width="165"
                  height="150"
                  fill={selectedEl === "RECINTO-A-P7" ? "rgba(59,130,246,0.22)" : "rgba(59,130,246,0.05)"}
                  stroke="rgba(59,130,246,0.45)"
                  className="cursor-pointer"
                  onClick={(event) => { event.stopPropagation(); setSelectedEl("RECINTO-A-P7"); }}
                />
                {[[205,110],[340,110],[205,235],[340,235],[380,110],[525,110],[555,110],[700,110],[555,235],[700,235],[205,270],[340,270],[205,430],[340,430],[555,270],[700,270],[555,430],[700,430]].map(([cx, cy], index) => (
                  <circle key={index} cx={cx} cy={cy} r="5" fill="#0b1019" stroke="#10b981" strokeWidth="1.2" />
                ))}
                <path d="M360 185 h-18 a18 18 0 0 1 18 18 M540 330 h18 a18 18 0 0 0 -18 18" fill="none" stroke="#f59e0b" strokeWidth="1.5" />
                <text x="270" y="175" textAnchor="middle" fill="#60a5fa" fontSize="12" fontFamily={MONO}>OFICINA A</text>
                <text x="450" y="175" textAnchor="middle" fill="#64748b" fontSize="11" fontFamily={MONO}>SALA REUNIÓN</text>
                <text x="625" y="175" textAnchor="middle" fill="#64748b" fontSize="11" fontFamily={MONO}>OFICINA B</text>
                <text x="270" y="350" textAnchor="middle" fill="#64748b" fontSize="11" fontFamily={MONO}>ÁREA ABIERTA</text>
                <text x="450" y="350" textAnchor="middle" fill="#22d3ee" fontSize="11" fontFamily={MONO}>NÚCLEO</text>
                <text x="625" y="350" textAnchor="middle" fill="#64748b" fontSize="11" fontFamily={MONO}>SERVICIOS</text>
                <text x="165" y="55" fill="#22d3ee" fontSize="10" fontFamily={MONO}>PLANTA NIVEL 07 · ESCALA 1:100</text>
              </motion.g>
            ) : (
              <motion.g
                key={viewMode}
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transform={viewMode === "ISO" ? "translate(35 18) rotate(-4 450 240) scale(0.94)" : undefined}
              >
                <polygon points="180,445 720,445 775,370 235,370" fill="rgba(59,130,246,0.04)" stroke="rgba(59,130,246,0.2)" strokeWidth="0.8" />
                {Array.from({ length: 14 }).map((_, floor) => {
                  const y = 370 - floor * 25;
                  const shrink = floor * 0.8;
                  const x1 = 180 + shrink;
                  const x2 = 720 - shrink;
                  const xo = 55 - floor * 0.4;
                  const isSelected = floor === 6;
                  return (
                    <g key={floor}>
                      <polygon
                        points={`${x1},${y} ${x2},${y} ${x2 + xo},${y - 18} ${x1 + xo},${y - 18}`}
                        fill={isSelected ? "rgba(59,130,246,0.18)" : viewMode === "ISO" ? "rgba(8,24,38,0.72)" : "rgba(8,12,20,0.85)"}
                        stroke={isSelected ? "rgba(59,130,246,0.9)" : viewMode === "ISO" ? "rgba(34,211,238,0.28)" : "rgba(59,130,246,0.18)"}
                        strokeWidth={isSelected ? 1.5 : 0.5}
                        filter={isSelected ? "url(#glow)" : undefined}
                        className="cursor-pointer"
                        onClick={(event) => { event.stopPropagation(); setSelectedEl(`MURO-EJE${String.fromCharCode(65 + (floor % 5))}${floor + 1}-P${floor + 1}`); }}
                      />
                      {[0.2, 0.4, 0.6, 0.8].map((frac, columnIndex) => {
                        const cx = x1 + (x2 - x1) * frac;
                        return <line key={columnIndex} x1={cx} y1={y} x2={cx + xo} y2={y - 18} stroke="rgba(6,182,212,0.2)" strokeWidth="0.4" />;
                      })}
                    </g>
                  );
                })}
                {[180, 315, 450, 585, 720].map((x, index) => (
                  <line key={index} x1={x} y1="370" x2={x} y2="20" stroke="rgba(59,130,246,0.1)" strokeWidth="0.4" strokeDasharray="3,5" />
                ))}
                <polygon points="195,30 705,30 760,10 250,10" fill="rgba(59,130,246,0.22)" stroke="#3b82f6" strokeWidth="1.5" filter="url(#glow)" />
                <line x1="195" y1="195" x2="150" y2="168" stroke="rgba(6,182,212,0.5)" strokeWidth="0.8" />
                <rect x="72" y="155" width="76" height="22" rx="3" fill="#0f1623" stroke="rgba(6,182,212,0.4)" strokeWidth="0.8" />
                <text x="110" y="170" textAnchor="middle" fill="#22d3ee" fontSize="8.5" fontFamily={MONO}>PISO 7 — SEL.</text>
                <line x1="718" y1="330" x2="770" y2="304" stroke="rgba(16,185,129,0.5)" strokeWidth="0.8" />
                <rect x="772" y="292" width="82" height="22" rx="3" fill="#0f1623" stroke="rgba(16,185,129,0.4)" strokeWidth="0.8" />
                <text x="813" y="307" textAnchor="middle" fill="#10b981" fontSize="8.5" fontFamily={MONO}>+68.0% avce.</text>
                <line x1="775" y1="370" x2="775" y2="30" stroke="rgba(255,255,255,0.07)" strokeWidth="0.5" />
                <text x="790" y="206" fill="#374151" fontSize="8" fontFamily={MONO} transform="rotate(90 790 206)">H = 42.0 m</text>
              </motion.g>
            )}
          </AnimatePresence>

          {/* North */}
          <g transform="translate(848, 520)">
            <circle cx="0" cy="0" r="16" fill="rgba(8,12,20,0.85)" stroke="rgba(255,255,255,0.1)" strokeWidth="0.8" />
            <polygon points="0,-11 4,5 0,1 -4,5" fill="#3b82f6" />
            <polygon points="0,11 4,-5 0,-1 -4,-5" fill="rgba(255,255,255,0.15)" />
            <text x="0" y="4" textAnchor="middle" fill="white" fontSize="7" fontFamily={MONO}>N</text>
          </g>

          {/* Selected tooltip */}
          {selectedEl && (
            <g>
              <rect x="18" y="18" width="162" height="44" rx="4" fill="rgba(8,12,20,0.95)" stroke="rgba(59,130,246,0.5)" strokeWidth="1" />
              <text x="28" y="34" fill="#22d3ee" fontSize="8.5" fontFamily={MONO}>ELEMENTO SELECCIONADO</text>
              <text x="28" y="50" fill="#94a3b8" fontSize="8.5" fontFamily={MONO}>{selectedEl}</text>
            </g>
          )}
        </svg>

        {/* Status bar */}
        <div className="absolute bottom-0 left-0 right-0 h-7 flex items-center gap-4 px-3 border-t border-border text-[9px] text-slate-700" style={{ background: "rgba(6,10,18,0.95)", fontFamily: MONO }}>
          <span>Herramienta: {activeTool}</span>
          <span>Vista: {viewMode}</span>
          <span>Zoom: {Math.round(zoom * 100)}%</span>
          <span>X: 12.340</span>
          <span>Y: 7.820</span>
          <span>Z: 19.600</span>
          <span className="ml-auto max-w-[42%] truncate text-slate-800">
            {selectedPlan ? `${selectedPlan.name} · ${selectedPlan.type}` : "Torre Bío-Bío · Arq. v4.0 · IFC 4.0"} · {new Date().toLocaleDateString("es-CL")}
          </span>
        </div>
      </div>

      {/* Properties panel */}
      {showProps && (
        <div className="w-60 border-l border-border flex flex-col flex-shrink-0" style={{ background: "#0b1019" }}>
          <div className="flex items-center justify-between px-3 py-2.5 border-b border-border flex-shrink-0">
            <span className="text-xs font-semibold text-slate-300">Propiedades</span>
            <button onClick={() => setShowProps(false)} className="text-slate-600 hover:text-slate-400 transition-colors">
              <X size={12} />
            </button>
          </div>
          {props ? (
            <div className="flex-1 overflow-y-auto p-2.5">
              {Object.entries(props).map(([k, v]) => (
                <div key={k} className="flex justify-between items-start gap-2 py-1.5 border-b border-border/40">
                  <span className="text-[9px] text-slate-600 flex-shrink-0" style={{ fontFamily: MONO }}>{k}</span>
                  <span className="text-[10px] text-slate-300 text-right">{v}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center p-5 text-center">
              <Crosshair size={22} className="text-slate-800 mb-2.5" />
              <p className="text-[11px] text-slate-700 leading-relaxed">Haz clic en un elemento del modelo para ver sus propiedades</p>
            </div>
          )}
          <div className="border-t border-border p-3 flex-shrink-0">
            <div className="text-[9px] font-semibold text-slate-700 uppercase tracking-widest mb-2" style={{ fontFamily: MONO }}>Capas visibles</div>
            {["Estructura", "Arquitectura", "MMEESS", "Terminaciones"].map((layer) => (
              <div key={layer} className="flex items-center gap-2 py-1">
                <div className="w-2.5 h-2.5 rounded-sm bg-blue-500/50 border border-blue-500/30 flex-shrink-0" />
                <span className="text-[10px] text-slate-500 flex-1">{layer}</span>
                <Eye size={10} className="text-slate-700" />
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Planning (Gantt) ─────────────────────────────────────────────────────────
function Planning() {
  const { notify, openPrompt } = useUI();
  const [selectedTask, setSelectedTask] = useState<number | null>(null);
  const [tasks, setTasks] = useState(ganttTasks);
  const [onlyPending, setOnlyPending] = useState(false);
  const visibleTasks = onlyPending ? tasks.filter((task) => task.progress < 100) : tasks;
  const selectedTaskData = tasks.find((task) => task.id === selectedTask) ?? null;

  const updateTask = (field: "progress" | "start" | "duration", value: number) => {
    if (!selectedTask) return;
    setTasks((current) => current.map((task) => {
      if (task.id !== selectedTask) return task;
      if (field === "progress") return { ...task, progress: Math.max(0, Math.min(100, value)) };
      if (field === "start") {
        const start = Math.max(0, Math.min(TOTAL_WEEKS - 1, value));
        return { ...task, start, duration: Math.min(task.duration, TOTAL_WEEKS - start) };
      }
      return { ...task, duration: Math.max(1, Math.min(TOTAL_WEEKS - task.start, value)) };
    }));
  };

  const addTask = () => openPrompt({
    title: "Nueva actividad",
    label: "Nombre de la actividad",
    placeholder: "Ej. Instalación de luminarias",
    confirmLabel: "Agregar",
    onSubmit: (name) => {
      setTasks((current) => [...current, {
        id: Math.max(...current.map((task) => task.id), 0) + 1,
        name,
        start: 20,
        duration: 6,
        progress: 0,
        color: "#06b6d4",
        responsible: "Sin asignar",
      }]);
      notify("Actividad agregada a la planificación");
    },
  });

  return (
    <div className="p-3 sm:p-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
        <div className="flex items-center gap-2.5">
          <h2 className="text-sm font-semibold text-slate-200">Carta Gantt</h2>
          <span className="text-[9px] bg-white/5 border border-border px-2 py-0.5 rounded text-slate-500" style={{ fontFamily: MONO }}>Torre Bío-Bío · 36 semanas</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={() => setOnlyPending((value) => !value)} className={`flex items-center gap-1.5 text-[11px] border px-2.5 py-1.5 rounded transition-colors ${onlyPending ? "border-blue-500/40 bg-blue-600/15 text-blue-400" : "text-slate-400 bg-white/5 border-border hover:bg-white/8"}`}>
            <Filter size={11} /> Filtrar
          </button>
          <button onClick={() => { downloadText("planificacion-obratrack.csv", ["Actividad,Responsable,Avance", ...tasks.map((task) => `"${task.name}","${task.responsible}",${task.progress}%`)].join("\n")); notify("Planificación exportada"); }} className="flex items-center gap-1.5 text-[11px] text-slate-400 bg-white/5 border border-border px-2.5 py-1.5 rounded hover:bg-white/8 transition-colors">
            <Download size={11} /> Exportar
          </button>
          <button onClick={addTask} className="flex items-center gap-1.5 text-[11px] text-white bg-blue-600 px-2.5 py-1.5 rounded hover:bg-blue-700 transition-colors">
            <Plus size={11} /> Actividad
          </button>
        </div>
      </div>

      <section className="mb-4 rounded-lg border border-border p-3" style={{ background: "#0f1623" }}>
        <div className="mb-3 flex items-center justify-between">
          <div>
            <h3 className="text-xs font-semibold text-slate-200">Tareas por atender</h3>
            <p className="mt-0.5 text-[9px] uppercase tracking-widest text-slate-600" style={{ fontFamily: MONO }}>Pendientes y en revisión</p>
          </div>
          <span className="rounded-full border border-border bg-white/5 px-2 py-0.5 text-[9px] text-slate-500" style={{ fontFamily: MONO }}>
            {kanbanData.pendiente.length + kanbanData.revision.length} tareas
          </span>
        </div>
        <div className="grid gap-2 lg:grid-cols-2">
          {[
            { id: "pendiente", label: "Pendientes", color: "#64748b", items: kanbanData.pendiente },
            { id: "revision", label: "En revisión", color: "#f59e0b", items: kanbanData.revision },
          ].map((group) => (
            <div key={group.id} className="rounded-md border border-border/70 bg-black/10 p-2.5">
              <div className="mb-2 flex items-center gap-2">
                <span className="h-2 w-2 rounded-full" style={{ background: group.color }} />
                <span className="text-[10px] font-semibold text-slate-400">{group.label}</span>
                <span className="ml-auto text-[9px] text-slate-600" style={{ fontFamily: MONO }}>{group.items.length}</span>
              </div>
              <div className="grid gap-1.5 sm:grid-cols-2">
                {group.items.map((task) => (
                  <div key={task.id} className="flex min-w-0 items-center gap-2 rounded bg-white/3 px-2 py-1.5">
                    <span className={`shrink-0 rounded px-1 py-0.5 text-[7px] font-semibold uppercase ${priorityBadge[task.priority]}`}>{task.priority}</span>
                    <span className="truncate text-[10px] text-slate-300">{task.title}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <div className="rounded-lg border border-border overflow-auto" style={{ background: "#0f1623" }}>
        <div style={{ minWidth: 960 }}>
          {/* Header */}
          <div className="flex border-b border-border sticky top-0 z-10" style={{ background: "#0f1623" }}>
            <div className="w-64 flex-shrink-0 px-3 py-2 border-r border-border">
              <span className="text-[9px] font-semibold text-slate-600 uppercase tracking-widest" style={{ fontFamily: MONO }}>Actividad</span>
            </div>
            <div className="w-20 flex-shrink-0 px-2 py-2 border-r border-border text-center">
              <span className="text-[9px] font-semibold text-slate-600 uppercase tracking-widest" style={{ fontFamily: MONO }}>Resp.</span>
            </div>
            <div className="w-16 flex-shrink-0 px-2 py-2 border-r border-border text-center">
              <span className="text-[9px] font-semibold text-slate-600 uppercase tracking-widest" style={{ fontFamily: MONO }}>%</span>
            </div>
            <div className="flex-1 relative">
              <div className="flex">
                {Array.from({ length: TOTAL_WEEKS }).map((_, i) => (
                  <div key={i} className={`flex-1 py-2 text-center border-r border-border/20 ${i === 20 ? "bg-blue-600/8" : ""}`} style={{ minWidth: 18 }}>
                    {i % 4 === 0 && (
                      <span className="text-[7px] text-slate-700" style={{ fontFamily: MONO }}>{`S${String(i + 1).padStart(2, "0")}`}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Tasks */}
          {visibleTasks.map((task) => {
            const initials = task.responsible.split(" ").map((n) => n[0]).join("");
            return (
              <div
                key={task.id}
                className={`flex border-b border-border/40 cursor-pointer transition-colors ${selectedTask === task.id ? "bg-blue-600/6" : "hover:bg-white/2"}`}
                onClick={() => setSelectedTask(task.id === selectedTask ? null : task.id)}
              >
                <div className="w-64 flex-shrink-0 flex items-center gap-2 px-3 py-2.5 border-r border-border">
                  <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: task.color }} />
                  <span className="text-xs text-slate-300 truncate">{task.name}</span>
                </div>
                <div className="w-20 flex-shrink-0 flex items-center justify-center px-2 py-2.5 border-r border-border">
                  <div className="w-6 h-6 rounded-full bg-slate-800 flex items-center justify-center border border-border">
                    <span className="text-[8px] font-bold text-slate-400">{initials}</span>
                  </div>
                </div>
                <div className="w-16 flex-shrink-0 flex items-center justify-center px-2 py-2.5 border-r border-border">
                  <span
                    className="text-[10px] font-bold"
                    style={{ color: task.progress === 100 ? "#10b981" : task.progress > 50 ? "#3b82f6" : "#94a3b8", fontFamily: MONO }}
                  >
                    {task.progress}%
                  </span>
                </div>
                <div className="flex-1 relative flex items-center" style={{ minWidth: 0 }}>
                  {/* Week grid bg */}
                  <div className="absolute inset-0 flex pointer-events-none">
                    {Array.from({ length: TOTAL_WEEKS }).map((_, i) => (
                      <div key={i} className={`flex-1 border-r border-border/10 ${i === 20 ? "bg-blue-600/5" : ""}`} style={{ minWidth: 18 }} />
                    ))}
                  </div>
                  {/* Bar */}
                  <div
                    className="absolute rounded overflow-hidden"
                    style={{
                      left: `${(task.start / TOTAL_WEEKS) * 100}%`,
                      width: `${(task.duration / TOTAL_WEEKS) * 100}%`,
                      height: 18,
                      top: "50%",
                      transform: "translateY(-50%)",
                      background: `${task.color}20`,
                      border: `1px solid ${task.color}50`,
                    }}
                  >
                    <motion.div
                      className="h-full rounded"
                      initial={{ width: 0 }}
                      animate={{ width: `${task.progress}%` }}
                      transition={{ duration: 0.6, delay: Math.min(task.id * 0.04, 0.32), ease: EASE_OUT }}
                      style={{ background: task.color, opacity: 0.65 }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <AnimatePresence>
        {selectedTaskData && (
          <motion.div
            initial={{ opacity: 0, y: -8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -6 }}
            className="mt-3 rounded-lg border border-blue-500/25 bg-blue-500/5 p-4"
          >
            <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="text-[9px] font-semibold uppercase tracking-widest text-blue-400" style={{ fontFamily: MONO }}>Editar actividad</div>
                <h3 className="mt-1 text-sm font-semibold text-slate-100">{selectedTaskData.name}</h3>
              </div>
              <div className={`rounded-full px-2.5 py-1 text-[9px] font-semibold ${selectedTaskData.progress === 100 ? "bg-emerald-500/15 text-emerald-400" : selectedTaskData.progress >= 50 ? "bg-blue-500/15 text-blue-400" : "bg-slate-500/15 text-slate-400"}`}>
                {selectedTaskData.progress === 100 ? "Completada" : selectedTaskData.progress > 0 ? "En ejecución" : "Pendiente"}
              </div>
            </div>

            <div className="grid gap-4 lg:grid-cols-[1fr_150px_150px]">
              <label>
                <span className="mb-2 flex items-center justify-between text-[10px] text-slate-500">
                  <span>Avance ejecutado</span>
                  <strong className="text-sm text-blue-400">{selectedTaskData.progress}%</strong>
                </span>
                <input
                  type="range"
                  min="0"
                  max="100"
                  step="5"
                  value={selectedTaskData.progress}
                  onChange={(event) => updateTask("progress", Number(event.target.value))}
                  className="h-2 w-full cursor-pointer accent-blue-500"
                  aria-label="Porcentaje de avance"
                />
                <div className="mt-2 flex flex-wrap gap-1">
                  {[0, 25, 50, 75, 100].map((value) => (
                    <button
                      key={value}
                      onClick={() => updateTask("progress", value)}
                      className={`rounded border px-2 py-1 text-[9px] ${selectedTaskData.progress === value ? "border-blue-500/40 bg-blue-500/15 text-blue-400" : "border-border text-slate-600 hover:text-slate-300"}`}
                    >
                      {value}%
                    </button>
                  ))}
                </div>
              </label>

              <label>
                <span className="mb-2 block text-[10px] text-slate-500">Semana de inicio</span>
                <input
                  type="number"
                  min="1"
                  max={TOTAL_WEEKS}
                  value={selectedTaskData.start + 1}
                  onChange={(event) => updateTask("start", Number(event.target.value) - 1)}
                  className="w-full rounded-md border border-border bg-black/20 px-3 py-2 text-sm text-slate-200 outline-none focus:border-blue-500"
                />
                <span className="mt-1 block text-[9px] text-slate-700">S{String(selectedTaskData.start + 1).padStart(2, "0")}</span>
              </label>

              <label>
                <span className="mb-2 block text-[10px] text-slate-500">Duración (semanas)</span>
                <input
                  type="number"
                  min="1"
                  max={TOTAL_WEEKS - selectedTaskData.start}
                  value={selectedTaskData.duration}
                  onChange={(event) => updateTask("duration", Number(event.target.value))}
                  className="w-full rounded-md border border-border bg-black/20 px-3 py-2 text-sm text-slate-200 outline-none focus:border-blue-500"
                />
                <span className="mt-1 block text-[9px] text-slate-700">Termina en S{String(selectedTaskData.start + selectedTaskData.duration).padStart(2, "0")}</span>
              </label>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex items-center gap-5 mt-3">
        {[
          { color: "rgba(59,130,246,0.25)", border: "rgba(59,130,246,0.5)", label: "Planificado" },
          { color: "#3b82f6", border: "#3b82f6", label: "Avance real" },
        ].map((l) => (
          <div key={l.label} className="flex items-center gap-1.5">
            <div className="w-5 h-2 rounded" style={{ background: l.color, border: `1px solid ${l.border}` }} />
            <span className="text-[10px] text-slate-600" style={{ fontFamily: MONO }}>{l.label}</span>
          </div>
        ))}
        <div className="flex items-center gap-1.5">
          <div className="w-2 h-2 rounded-full bg-blue-600/30 border border-blue-500/50" />
          <span className="text-[10px] text-slate-600" style={{ fontFamily: MONO }}>Semana actual (S21)</span>
        </div>
      </div>
    </div>
  );
}

// ─── Kanban ──────────────────────────────────────────────────────────────────────
type KanbanItem = { id: number; title: string; priority: string; assignee: string; tag: string; dueDate: string };

const kanbanCols = [
  { id: "pendiente", label: "Pendiente", color: "#64748b" },
  { id: "ejecucion", label: "En Ejecución", color: "#3b82f6" },
  { id: "revision", label: "En Revisión", color: "#f59e0b" },
  { id: "finalizado", label: "Finalizado", color: "#10b981" },
];

function KanbanCard({ item, columnIndex, onMove, onDelete }: { item: KanbanItem; columnIndex: number; onMove: (direction: -1 | 1) => void; onDelete: () => void }) {
  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 10, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, x: 18, scale: 0.96 }}
      whileHover={{ y: -2 }}
      transition={SPRING_SNAPPY}
      className="rounded-md border border-border p-2.5 cursor-default hover:border-slate-700 transition-colors"
      style={{ background: "#0b1019" }}
    >
      <div className="flex items-start justify-between gap-2 mb-2">
        <span className="text-[11px] text-slate-200 leading-snug">{item.title}</span>
        <button onClick={onDelete} title="Eliminar tarea" className="text-slate-700 hover:text-red-400 flex-shrink-0"><Trash2 size={12} /></button>
      </div>
      <div className="flex items-center gap-1 flex-wrap">
        <span className={`text-[8px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wider ${priorityBadge[item.priority]}`} style={{ fontFamily: MONO }}>{item.priority}</span>
        <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/5 text-slate-500 border border-border" style={{ fontFamily: MONO }}>{item.tag}</span>
      </div>
      <div className="flex items-center justify-between mt-2">
        <span className="text-[9px] text-slate-700" style={{ fontFamily: MONO }}>{item.dueDate}</span>
        <div className="flex items-center gap-1">
          <button disabled={columnIndex === 0} onClick={() => onMove(-1)} title="Mover a la columna anterior" className="rounded p-0.5 text-slate-600 hover:bg-white/5 hover:text-white disabled:opacity-20"><ChevronLeft size={11} /></button>
          <div className="w-5 h-5 rounded-full bg-slate-800 border border-border flex items-center justify-center">
            <span className="text-[8px] font-bold text-slate-500">{item.assignee}</span>
          </div>
          <button disabled={columnIndex === kanbanCols.length - 1} onClick={() => onMove(1)} title="Mover a la columna siguiente" className="rounded p-0.5 text-slate-600 hover:bg-white/5 hover:text-white disabled:opacity-20"><ChevronRight size={11} /></button>
        </div>
      </div>
    </motion.div>
  );
}

function KanbanBoard() {
  const { notify, openPrompt } = useUI();
  const [board, setBoard] = useState(() => Object.fromEntries(Object.entries(kanbanData).map(([key, items]) => [key, [...items]])) as Record<string, KanbanItem[]>);

  const addTask = (columnId = "pendiente") => openPrompt({
    title: "Nueva tarea",
    label: "Título de la tarea",
    placeholder: "Ej. Revisar avance semanal",
    confirmLabel: "Crear tarea",
    onSubmit: (title) => {
      setBoard((current) => ({
        ...current,
        [columnId]: [...current[columnId], {
          id: Date.now(),
          title,
          priority: "media",
          assignee: "YO",
          tag: "General",
          dueDate: new Date().toISOString().slice(0, 10),
        }],
      }));
      notify("Tarea creada");
    },
  });

  const moveTask = (item: KanbanItem, fromId: string, direction: -1 | 1) => {
    const fromIndex = kanbanCols.findIndex((column) => column.id === fromId);
    const target = kanbanCols[fromIndex + direction];
    if (!target) return;
    setBoard((current) => ({
      ...current,
      [fromId]: current[fromId].filter((task) => task.id !== item.id),
      [target.id]: [...current[target.id], item],
    }));
    notify(`Tarea movida a ${target.label}`);
  };

  const deleteTask = (item: KanbanItem, columnId: string) => {
    setBoard((current) => ({ ...current, [columnId]: current[columnId].filter((task) => task.id !== item.id) }));
    notify("Tarea eliminada");
  };

  return (
    <div className="p-3 sm:p-5 flex flex-col" style={{ height: "calc(100vh - 112px)" }}>
      <div className="flex items-center justify-between gap-3 mb-4 flex-shrink-0">
        <h2 className="text-sm font-semibold text-slate-200">Tablero de tareas</h2>
        <button onClick={() => addTask()} className="flex items-center gap-1.5 text-[11px] text-white bg-blue-600 px-2.5 py-1.5 rounded hover:bg-blue-700 transition-colors">
          <Plus size={11} /> Nueva Tarea
        </button>
      </div>
      <div className="flex gap-3 flex-1 min-h-0 overflow-x-auto pb-2" style={{ scrollbarWidth: "thin" }}>
        {kanbanCols.map((col, columnIndex) => {
          const items = board[col.id];
          return (
            <div key={col.id} className="flex flex-col rounded-lg border border-border overflow-hidden flex-shrink-0 w-72 sm:flex-1" style={{ background: "#0f1623" }}>
              <div className="px-3 py-2.5 border-b border-border flex items-center justify-between flex-shrink-0">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full" style={{ background: col.color }} />
                  <span className="text-xs font-semibold text-slate-300">{col.label}</span>
                </div>
                <span className="text-[9px] bg-white/5 px-1.5 py-0.5 rounded text-slate-600 border border-border" style={{ fontFamily: MONO }}>{items.length}</span>
              </div>
              <div className="flex-1 overflow-y-auto p-2.5 space-y-2">
                <AnimatePresence initial={false}>
                  {items.map((item) => (
                    <KanbanCard
                      key={item.id}
                      item={item}
                      columnIndex={columnIndex}
                      onMove={(direction) => moveTask(item, col.id, direction)}
                      onDelete={() => deleteTask(item, col.id)}
                    />
                  ))}
                </AnimatePresence>
              </div>
              <div className="p-2 border-t border-border flex-shrink-0">
                <button onClick={() => addTask(col.id)} className="w-full flex items-center justify-center gap-1.5 py-1.5 text-[10px] text-slate-700 hover:text-slate-500 hover:bg-white/3 rounded transition-colors">
                  <Plus size={10} /> Agregar tarea
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ─── Calendar ─────────────────────────────────────────────────────────────────
function CalendarView() {
  const { notify, openDetails, openPrompt } = useUI();
  const [month, setMonth] = useState(() => new Date(2026, 10, 1));
  const [events, setEvents] = useState(() => calendarEvents.map((event) => ({ ...event, monthKey: "2026-10" })));
  const today = new Date();
  const days = ["Dom", "Lun", "Mar", "Mié", "Jue", "Vie", "Sáb"];
  const monthKey = `${month.getFullYear()}-${month.getMonth()}`;
  const startDay = new Date(month.getFullYear(), month.getMonth(), 1).getDay();
  const daysInMonth = new Date(month.getFullYear(), month.getMonth() + 1, 0).getDate();
  const cells: (number | null)[] = [];
  for (let i = 0; i < startDay; i++) cells.push(null);
  for (let i = 1; i <= daysInMonth; i++) cells.push(i);
  const getEvents = (day: number) => events.filter((event) => event.date === day && event.monthKey === monthKey);
  const monthLabel = new Intl.DateTimeFormat("es-CL", { month: "long", year: "numeric" }).format(month);

  const addEvent = (date = 22) => openPrompt({
    title: "Nuevo evento",
    label: "Nombre del evento",
    placeholder: "Ej. Reunión de coordinación",
    confirmLabel: "Crear evento",
    onSubmit: (title) => {
      setEvents((current) => [...current, { date: Math.min(date, daysInMonth), title, time: "09:00", color: "#3b82f6", monthKey }]);
      notify("Evento agregado al calendario");
    },
  });

  return (
    <div className="p-3 sm:p-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
        <h2 className="text-sm font-semibold capitalize text-slate-200">{monthLabel}</h2>
        <div className="flex flex-wrap items-center gap-2">
          <button onClick={() => setMonth((current) => new Date(current.getFullYear(), current.getMonth() - 1, 1))} aria-label="Mes anterior" className="px-2 py-1 text-slate-500 hover:text-slate-300 border border-border rounded text-xs">{"‹"}</button>
          <button onClick={() => setMonth((current) => new Date(current.getFullYear(), current.getMonth() + 1, 1))} aria-label="Mes siguiente" className="px-2 py-1 text-slate-500 hover:text-slate-300 border border-border rounded text-xs">{"›"}</button>
          <button onClick={() => addEvent()} className="flex items-center gap-1.5 text-[11px] text-white bg-blue-600 px-2.5 py-1.5 rounded hover:bg-blue-700 transition-colors">
            <Plus size={11} /> Evento
          </button>
        </div>
      </div>
      <div className="rounded-lg border border-border overflow-hidden" style={{ background: "#0f1623" }}>
        <div className="grid grid-cols-7 border-b border-border">
          {days.map((d) => (
            <div key={d} className="py-2 text-center text-[9px] text-slate-600 uppercase tracking-widest" style={{ fontFamily: MONO }}>{d}</div>
          ))}
        </div>
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={monthKey}
            initial={{ opacity: 0, x: 14 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -14 }}
            transition={{ duration: 0.24, ease: EASE_OUT }}
            className="grid grid-cols-7"
          >
            {cells.map((day, idx) => {
              const evts = day ? getEvents(day) : [];
              const isToday = day === today.getDate()
                && month.getMonth() === today.getMonth()
                && month.getFullYear() === today.getFullYear();
              return (
                <motion.div
                  key={idx}
                  whileHover={day ? { backgroundColor: "rgba(255,255,255,0.035)" } : undefined}
                  onClick={() => day && (evts.length ? openDetails(`Eventos del ${day}`, <div className="space-y-2">{evts.map((event) => <div key={`${event.time}-${event.title}`} className="rounded-md bg-white/5 p-2"><span className="font-mono text-xs text-blue-400">{event.time}</span> · {event.title}</div>)}</div>) : addEvent(day))}
                  className={`min-h-[88px] p-1.5 border-b border-r border-border/30 ${!day ? "bg-white/1" : "cursor-pointer"} transition-colors`}
                >
                  {day && (
                    <>
                      <div className={`w-6 h-6 rounded-full flex items-center justify-center mb-1 text-[11px] ${isToday ? "bg-blue-600 text-white font-bold" : "text-slate-500"}`} style={{ fontFamily: MONO }}>
                        {day}
                      </div>
                      <div className="space-y-0.5">
                        {evts.slice(0, 2).map((ev, ei) => (
                          <motion.div initial={{ opacity: 0, scale: 0.96 }} animate={{ opacity: 1, scale: 1 }} key={ei} className="rounded px-1 py-0.5 text-[8.5px] truncate" style={{ background: `${ev.color}20`, color: ev.color, borderLeft: `2px solid ${ev.color}`, fontFamily: MONO }}>
                            {ev.time} {ev.title}
                          </motion.div>
                        ))}
                        {evts.length > 2 && <div className="text-[8px] text-slate-600 pl-1" style={{ fontFamily: MONO }}>+{evts.length - 2} más</div>}
                      </div>
                    </>
                  )}
                </motion.div>
              );
            })}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

// ─── Documents ────────────────────────────────────────────────────────────────
function Documents() {
  const { notify, openDetails, openPrompt } = useUI();
  const [viewMode, setViewMode] = useState<"list" | "grid">("list");
  const [documentList, setDocumentList] = useState(documents);

  const showDocument = (doc: typeof documents[number]) => openDetails(doc.name, (
    <dl className="grid grid-cols-2 gap-3">
      <div><dt className="text-[10px] uppercase text-slate-600">Tipo</dt><dd>{doc.type}</dd></div>
      <div><dt className="text-[10px] uppercase text-slate-600">Versión</dt><dd>v{doc.version}</dd></div>
      <div><dt className="text-[10px] uppercase text-slate-600">Autor</dt><dd>{doc.author}</dd></div>
      <div><dt className="text-[10px] uppercase text-slate-600">Estado</dt><dd>{doc.status.replace("_", " ")}</dd></div>
    </dl>
  ));

  const addDocument = () => openPrompt({
    title: "Subir documento",
    label: "Nombre del documento",
    placeholder: "Ej. Informe de avance semanal",
    confirmLabel: "Subir",
    onSubmit: (name) => {
      setDocumentList((current) => [...current, {
        id: Math.max(...current.map((doc) => doc.id), 0) + 1,
        name,
        type: "PDF",
        size: "—",
        updatedAt: new Date().toISOString().slice(0, 10),
        status: "pendiente",
        author: "Usuario actual",
        version: "1.0",
      }]);
      notify("Documento agregado");
    },
  });

  return (
    <div className="p-3 sm:p-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
        <h2 className="text-sm font-semibold text-slate-200">Gestión Documental</h2>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex rounded-md border border-border overflow-hidden">
            <button onClick={() => setViewMode("list")} className={`p-1.5 transition-colors ${viewMode === "list" ? "bg-blue-600 text-white" : "bg-white/5 text-slate-600 hover:text-slate-300"}`}><List size={12} /></button>
            <button onClick={() => setViewMode("grid")} className={`p-1.5 transition-colors ${viewMode === "grid" ? "bg-blue-600 text-white" : "bg-white/5 text-slate-600 hover:text-slate-300"}`}><LayoutGrid size={12} /></button>
          </div>
          <button onClick={addDocument} className="flex items-center gap-1.5 text-[11px] text-white bg-blue-600 px-2.5 py-1.5 rounded hover:bg-blue-700 transition-colors">
            <Upload size={11} /> Subir documento
          </button>
        </div>
      </div>

      <AnimatePresence mode="wait" initial={false}>
      {viewMode === "list" ? (
      <motion.div key="documents-list" layout initial={{ opacity: 0, x: -10 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 10 }} transition={{ duration: 0.2, ease: EASE_OUT }} className="rounded-lg border border-border overflow-hidden" style={{ background: "#0f1623" }}>
        <div className="overflow-x-auto">
        <table className="w-full min-w-[640px]">
          <thead>
            <tr className="border-b border-border">
              {["Documento", "Tipo", "Versión", "Autor", "Actualizado", "Estado", "Tamaño", ""].map((h) => (
                <th key={h} className="text-left px-3 py-2.5 text-[9px] font-semibold text-slate-600 uppercase tracking-widest" style={{ fontFamily: MONO }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {documentList.map((doc) => (
              <tr key={doc.id} onClick={() => showDocument(doc)} className="border-b border-border/40 hover:bg-white/2 transition-colors cursor-pointer">
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded flex items-center justify-center flex-shrink-0" style={{ background: `${fileTypeColor[doc.type] || "#475569"}15`, border: `1px solid ${fileTypeColor[doc.type] || "#475569"}35` }}>
                      <span className="text-[7px] font-bold" style={{ color: fileTypeColor[doc.type] || "#94a3b8", fontFamily: MONO }}>{doc.type}</span>
                    </div>
                    <span className="text-xs text-slate-300">{doc.name}</span>
                  </div>
                </td>
                <td className="px-3 py-2.5"><span className="text-[10px] text-slate-500" style={{ fontFamily: MONO }}>{doc.type}</span></td>
                <td className="px-3 py-2.5"><span className="text-[10px] text-slate-400" style={{ fontFamily: MONO }}>v{doc.version}</span></td>
                <td className="px-3 py-2.5"><span className="text-xs text-slate-400">{doc.author}</span></td>
                <td className="px-3 py-2.5"><span className="text-[10px] text-slate-600" style={{ fontFamily: MONO }}>{doc.updatedAt}</span></td>
                <td className="px-3 py-2.5">
                  <span className={`text-[9px] px-2 py-0.5 rounded ${statusBadge[doc.status]}`} style={{ fontFamily: MONO }}>{doc.status.replace("_", " ")}</span>
                </td>
                <td className="px-3 py-2.5"><span className="text-[10px] text-slate-600" style={{ fontFamily: MONO }}>{doc.size}</span></td>
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-1">
                    <button onClick={(event) => { event.stopPropagation(); showDocument(doc); }} title="Ver detalles" className="p-1 text-slate-700 hover:text-slate-400 rounded transition-colors"><Eye size={12} /></button>
                    <button onClick={(event) => { event.stopPropagation(); downloadText(`${doc.name}.txt`, `Documento: ${doc.name}\nVersión: ${doc.version}\nEstado: ${doc.status}`, "text/plain;charset=utf-8"); notify("Descarga iniciada"); }} title="Descargar" className="p-1 text-slate-700 hover:text-slate-400 rounded transition-colors"><Download size={12} /></button>
                    <button onClick={(event) => { event.stopPropagation(); notify("Acciones del documento disponibles"); }} title="Más acciones" className="p-1 text-slate-700 hover:text-slate-400 rounded transition-colors"><MoreHorizontal size={12} /></button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </motion.div>
      ) : (
        <motion.div key="documents-grid" layout variants={STAGGER_CONTAINER} initial="hidden" animate="visible" exit={{ opacity: 0, x: -10 }} className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {documentList.map((doc) => (
            <motion.button
              layout
              variants={STAGGER_ITEM}
              key={doc.id}
              onClick={() => showDocument(doc)}
              whileHover={{ y: -3 }}
              className="rounded-lg border border-border p-4 text-left transition-colors hover:border-blue-500/35"
              style={{ background: "#0f1623" }}
            >
              <div className="mb-4 flex items-start justify-between">
                <div className="flex h-10 w-10 items-center justify-center rounded-md" style={{ background: `${fileTypeColor[doc.type] || "#475569"}15`, border: `1px solid ${fileTypeColor[doc.type] || "#475569"}35` }}>
                  <span className="text-[9px] font-bold" style={{ color: fileTypeColor[doc.type] || "#94a3b8", fontFamily: MONO }}>{doc.type}</span>
                </div>
                <span className={`rounded px-2 py-0.5 text-[9px] ${statusBadge[doc.status]}`}>{doc.status.replace("_", " ")}</span>
              </div>
              <div className="min-h-10 text-xs font-medium text-slate-200">{doc.name}</div>
              <div className="mt-3 flex justify-between text-[9px] text-slate-600"><span>v{doc.version}</span><span>{doc.size}</span></div>
            </motion.button>
          ))}
        </motion.div>
      )}
      </AnimatePresence>
    </div>
  );
}

// ─── Inspections ──────────────────────────────────────────────────────────────
function Inspections() {
  const { notify, openDetails, openPrompt } = useUI();
  const [inspectionList, setInspectionList] = useState(inspections);

  const addInspection = () => openPrompt({
    title: "Nueva inspección",
    label: "Nombre de la inspección",
    placeholder: "Ej. Control de terminaciones",
    confirmLabel: "Crear",
    onSubmit: (title) => {
      setInspectionList((current) => [...current, {
        id: Math.max(...current.map((inspection) => inspection.id), 0) + 1,
        title,
        date: new Date().toISOString().slice(0, 10),
        responsible: "Usuario actual",
        priority: "media",
        status: "abierta",
        location: "Por definir",
        photos: 0,
      }]);
      notify("Inspección creada");
    },
  });

  return (
    <div className="p-3 sm:p-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between mb-4">
        <h2 className="text-sm font-semibold text-slate-200">Inspecciones</h2>
        <button onClick={addInspection} className="flex items-center gap-1.5 text-[11px] text-white bg-blue-600 px-2.5 py-1.5 rounded hover:bg-blue-700 transition-colors">
          <Plus size={11} /> Nueva Inspección
        </button>
      </div>
      <div className="space-y-2.5">
        {inspectionList.map((insp) => (
          <motion.div
            layout
            key={insp.id}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            whileHover={{ y: -2 }}
            transition={{ duration: 0.3, ease: EASE_OUT }}
            className="rounded-lg border border-border p-3.5 hover:border-slate-700 transition-colors cursor-pointer"
            style={{ background: "#0f1623" }}
          >
            <div className="flex items-start justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 mb-1.5">
                  <span className={`text-[8px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wider ${priorityBadge[insp.priority]}`} style={{ fontFamily: MONO }}>{insp.priority}</span>
                  <span className={`text-[9px] px-1.5 py-0.5 rounded ${statusBadge[insp.status]}`} style={{ fontFamily: MONO }}>{insp.status.replace("_", " ")}</span>
                </div>
                <h3 className="text-sm font-medium text-slate-200 mb-1.5">{insp.title}</h3>
                <div className="flex items-center gap-4 text-[10px] text-slate-600 flex-wrap" style={{ fontFamily: MONO }}>
                  <span>📍 {insp.location}</span>
                  <span>👤 {insp.responsible}</span>
                  <span>📅 {insp.date}</span>
                  <span>📷 {insp.photos} fotos</span>
                </div>
              </div>
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <button onClick={() => openDetails(insp.title, <div className="space-y-2"><p>{insp.location}</p><p>Responsable: {insp.responsible}</p><p>Estado: {insp.status.replace("_", " ")}</p><p>{insp.photos} fotografías registradas</p></div>)} title="Ver inspección" className="p-1.5 text-slate-700 hover:text-slate-400 rounded border border-border transition-colors"><Eye size={12} /></button>
                <button onClick={() => { setInspectionList((current) => current.map((item) => item.id === insp.id ? { ...item, photos: item.photos + 1 } : item)); notify("Fotografía adjuntada"); }} title="Adjuntar fotografía" className="p-1.5 text-slate-700 hover:text-slate-400 rounded border border-border transition-colors"><Upload size={12} /></button>
              </div>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
}

// ─── Issues ───────────────────────────────────────────────────────────────────
function Issues() {
  const { notify, openDetails, openPrompt } = useUI();
  const [filter, setFilter] = useState("Todas");
  const [issueList, setIssueList] = useState(issues);
  const filters = ["Todas", "Abiertas", "En revisión", "Cerradas"];
  const visibleIssues = issueList.filter((issue) => {
    if (filter === "Abiertas") return issue.status === "abierta";
    if (filter === "En revisión") return issue.status === "en_revision";
    if (filter === "Cerradas") return issue.status === "cerrada";
    return true;
  });

  const addIssue = () => openPrompt({
    title: "Nueva incidencia",
    label: "Título de la incidencia",
    placeholder: "Describe brevemente el problema",
    confirmLabel: "Registrar",
    onSubmit: (title) => {
      setIssueList((current) => [{
        id: `INC-${String(43 + current.length).padStart(3, "0")}`,
        title,
        description: "Incidencia registrada desde ObraTrack",
        priority: "media",
        status: "abierta",
        responsible: "Por asignar",
        created: new Date().toISOString().slice(0, 10),
        element: "",
      }, ...current]);
      setFilter("Todas");
      notify("Incidencia registrada");
    },
  });

  return (
    <div className="p-3 sm:p-5">
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between mb-4">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:gap-3">
          <h2 className="text-sm font-semibold text-slate-200">Incidencias</h2>
          <div className="flex flex-wrap gap-1">
            {filters.map((f) => (
              <button
                key={f}
                onClick={() => setFilter(f)}
                className={`text-[10px] px-2.5 py-1 rounded border transition-colors ${filter === f ? "bg-blue-600/15 border-blue-500/35 text-blue-400" : "border-border text-slate-600 hover:text-slate-300 bg-white/3"}`}
                style={{ fontFamily: MONO }}
              >
                {f}
              </button>
            ))}
          </div>
        </div>
        <button onClick={addIssue} className="flex items-center gap-1.5 text-[11px] text-white bg-blue-600 px-2.5 py-1.5 rounded hover:bg-blue-700 transition-colors">
          <Plus size={11} /> Nueva Incidencia
        </button>
      </div>
      <div className="rounded-lg border border-border overflow-hidden" style={{ background: "#0f1623" }}>
        <div className="overflow-x-auto">
        <table className="w-full min-w-[600px]">
          <thead>
            <tr className="border-b border-border">
              {["ID", "Título", "Prioridad", "Estado", "Responsable", "Elemento BIM", "Fecha"].map((h) => (
                <th key={h} className="text-left px-3 py-2.5 text-[9px] font-semibold text-slate-600 uppercase tracking-widest" style={{ fontFamily: MONO }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visibleIssues.map((issue) => (
              <tr key={issue.id} onClick={() => openDetails(issue.title, <div className="space-y-2"><p>{issue.description}</p><p className="text-xs text-slate-500">Responsable: {issue.responsible}</p><button onClick={() => { setIssueList((current) => current.map((item) => item.id === issue.id ? { ...item, status: "cerrada" } : item)); notify("Incidencia cerrada"); }} className="mt-2 rounded bg-emerald-600 px-3 py-2 text-xs font-semibold text-white">Marcar como cerrada</button></div>)} className="border-b border-border/40 hover:bg-white/2 transition-colors cursor-pointer">
                <td className="px-3 py-3"><span className="text-[10px] text-blue-400" style={{ fontFamily: MONO }}>{issue.id}</span></td>
                <td className="px-3 py-3">
                  <div className="text-xs font-medium text-slate-200">{issue.title}</div>
                  <div className="text-[10px] text-slate-600 mt-0.5 max-w-xs truncate" style={{ fontFamily: MONO }}>{issue.description}</div>
                </td>
                <td className="px-3 py-3">
                  <span className={`text-[8px] px-1.5 py-0.5 rounded font-semibold uppercase tracking-wider ${priorityBadge[issue.priority]}`} style={{ fontFamily: MONO }}>{issue.priority}</span>
                </td>
                <td className="px-3 py-3">
                  <span className={`text-[9px] px-2 py-0.5 rounded ${statusBadge[issue.status]}`} style={{ fontFamily: MONO }}>{issue.status.replace("_", " ")}</span>
                </td>
                <td className="px-3 py-3"><span className="text-xs text-slate-400">{issue.responsible}</span></td>
                <td className="px-3 py-3">
                  {issue.element
                    ? <span className="text-[9px] text-cyan-400/70 bg-cyan-500/8 border border-cyan-500/20 px-1.5 py-0.5 rounded" style={{ fontFamily: MONO }}>{issue.element}</span>
                    : <span className="text-slate-700">—</span>
                  }
                </td>
                <td className="px-3 py-3"><span className="text-[10px] text-slate-600" style={{ fontFamily: MONO }}>{issue.created}</span></td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
}

function ControlCenter() {
  const [section, setSection] = useState<"inspections" | "issues">("inspections");

  return (
    <div>
      <div className="border-b border-border px-3 pt-3 sm:px-5 sm:pt-5">
        <div className="inline-flex rounded-lg border border-border bg-white/3 p-1">
          {[
            { id: "inspections" as const, label: "Inspecciones", count: inspections.length },
            { id: "issues" as const, label: "Incidencias", count: issues.length },
          ].map((item) => (
            <button
              key={item.id}
              onClick={() => setSection(item.id)}
              className={`flex items-center gap-2 rounded-md px-3 py-1.5 text-[11px] font-medium transition-colors ${
                section === item.id ? "bg-blue-600 text-white" : "text-slate-500 hover:bg-white/5 hover:text-slate-200"
              }`}
            >
              {item.label}
              <span className={`rounded-full px-1.5 py-0.5 text-[8px] ${section === item.id ? "bg-white/15 text-white" : "bg-white/5 text-slate-600"}`} style={{ fontFamily: MONO }}>
                {item.count}
              </span>
            </button>
          ))}
        </div>
      </div>
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={section}
          initial={{ opacity: 0, x: 8 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -8 }}
          transition={{ duration: 0.2, ease: EASE_OUT }}
        >
          {section === "inspections" ? <Inspections /> : <Issues />}
        </motion.div>
      </AnimatePresence>
    </div>
  );
}

// ─── Reports ─────────────────────────────────────────────────────────────────
function Reports() {
  const { notify } = useUI();
  const indicators = [
    { label: "SPI (Schedule Performance Index)", value: "0.87", pct: 87, status: "warning" },
    { label: "CPI (Cost Performance Index)", value: "0.94", pct: 94, status: "warning" },
    { label: "Productividad HH", value: "83%", pct: 83, status: "good" },
    { label: "Índice de Calidad ITO", value: "96%", pct: 96, status: "good" },
    { label: "Tasa Incidencias / Semana", value: "2.3", pct: 46, status: "neutral" },
    { label: "Documentos en Regla", value: "78%", pct: 78, status: "warning" },
  ];

  return (
    <div className="p-3 sm:p-5 space-y-4">
      <div className="flex items-center justify-between">
        <h2 className="text-sm font-semibold text-slate-200">Reportes y KPIs</h2>
        <div className="flex items-center gap-2">
          <button onClick={() => { notify("Vista de impresión preparada"); window.setTimeout(() => window.print(), 150); }} className="flex items-center gap-1.5 text-[11px] text-slate-400 bg-white/5 border border-border px-2.5 py-1.5 rounded hover:bg-white/8 transition-colors"><Download size={11} /> PDF</button>
          <button onClick={() => { downloadText("reporte-kpis-obratrack.csv", ["Indicador,Valor,Porcentaje", ...indicators.map((item) => `"${item.label}",${item.value},${item.pct}%`)].join("\n")); notify("Reporte Excel descargado"); }} className="flex items-center gap-1.5 text-[11px] text-slate-400 bg-white/5 border border-border px-2.5 py-1.5 rounded hover:bg-white/8 transition-colors"><Download size={11} /> Excel</button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* Weekly */}
        <div className="rounded-lg border border-border p-4" style={{ background: "#0f1623" }}>
          <h3 className="text-xs font-semibold text-slate-300 mb-3">Avance Diario — Semana 47</h3>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={reportsWeekly}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="day" tick={{ fill: "#475569", fontSize: 9, fontFamily: MONO }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#475569", fontSize: 9, fontFamily: MONO }} axisLine={false} tickLine={false} unit="%" />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 6, fontSize: 11 }} />
              <Bar key="reports-weekly-meta" dataKey="meta" fill="rgba(59,130,246,0.12)" name="Meta" radius={[2, 2, 0, 0]} />
              <Bar key="reports-weekly-avance" dataKey="avance" fill="#3b82f6" name="Avance" radius={[2, 2, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* HH */}
        <div className="rounded-lg border border-border p-4" style={{ background: "#0f1623" }}>
          <h3 className="text-xs font-semibold text-slate-300 mb-3">Horas Hombre (HH) Mensuales</h3>
          <ResponsiveContainer width="100%" height={200}>
            <LineChart data={reportsHH}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.04)" />
              <XAxis dataKey="month" tick={{ fill: "#475569", fontSize: 9, fontFamily: MONO }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fill: "#475569", fontSize: 9, fontFamily: MONO }} axisLine={false} tickLine={false} />
              <Tooltip contentStyle={{ background: "#111827", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 6, fontSize: 11 }} />
              <Line key="reports-hours-plan" type="monotone" dataKey="plan" stroke="#334155" strokeWidth={1.5} strokeDasharray="4 2" name="Plan" dot={false} activeDot={false} />
              <Line key="reports-hours-real" type="monotone" dataKey="real" stroke="#10b981" strokeWidth={2} name="Real" dot={{ fill: "#10b981", r: 3, strokeWidth: 0 }} activeDot={{ r: 4, fill: "#10b981", stroke: "#d1fae5", strokeWidth: 2 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Pie issues */}
        <div className="rounded-lg border border-border p-4" style={{ background: "#0f1623" }}>
          <h3 className="text-xs font-semibold text-slate-300 mb-3">Incidencias por Prioridad</h3>
          <div className="flex items-center gap-6">
            <PieChart width={130} height={130}>
              <Pie
                data={[{ name: "Crítica", value: 2 }, { name: "Alta", value: 5 }, { name: "Media", value: 3 }, { name: "Baja", value: 2 }]}
                cx="50%" cy="50%" innerRadius={33} outerRadius={52} dataKey="value" strokeWidth={0}
              >
                {["#ef4444", "#f97316", "#f59e0b", "#64748b"].map((c, i) => <Cell key={`issues-pie-${i}`} fill={c} />)}
              </Pie>
            </PieChart>
            <div className="space-y-2.5">
              {[{ label: "Crítica", count: 2, color: "#ef4444" }, { label: "Alta", count: 5, color: "#f97316" }, { label: "Media", count: 3, color: "#f59e0b" }, { label: "Baja", count: 2, color: "#64748b" }].map((it) => (
                <div key={it.label} className="flex items-center gap-2.5">
                  <div className="w-2.5 h-2.5 rounded-full flex-shrink-0" style={{ background: it.color }} />
                  <span className="text-xs text-slate-400 flex-1">{it.label}</span>
                  <span className="text-xs font-bold text-slate-300" style={{ fontFamily: MONO }}>{it.count}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* KPIs */}
        <div className="rounded-lg border border-border p-4" style={{ background: "#0f1623" }}>
          <h3 className="text-xs font-semibold text-slate-300 mb-4">Indicadores de Gestión</h3>
          <div className="space-y-3">
            {indicators.map((kpi) => (
              <div key={kpi.label} className="flex items-center justify-between gap-3">
                <span className="text-[11px] text-slate-500 flex-1 truncate">{kpi.label}</span>
                <div className="flex items-center gap-2 flex-shrink-0">
                  <div className="w-20 h-1.5 rounded-full bg-white/6 overflow-hidden">
                    <motion.div
                      className="h-full rounded-full"
                      initial={{ width: 0 }}
                      animate={{ width: `${kpi.pct}%` }}
                      transition={{ duration: 0.65, ease: EASE_OUT }}
                      style={{ background: kpi.status === "good" ? "#10b981" : kpi.status === "warning" ? "#f59e0b" : "#475569" }}
                    />
                  </div>
                  <span
                    className="text-[10px] font-bold w-10 text-right"
                    style={{ fontFamily: MONO, color: kpi.status === "good" ? "#10b981" : kpi.status === "warning" ? "#f59e0b" : "#64748b" }}
                  >
                    {kpi.value}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Map ──────────────────────────────────────────────────────────────────────
const mapMarkers = [
  { lat: -23.650927, lng: -70.397502, city: "Antofagasta", address: "Centro de Antofagasta, Región de Antofagasta", project: projects[1], color: "#3b82f6" },
  { lat: -36.820135, lng: -73.04439, city: "Concepción", address: "Centro de Concepción, Región del Biobío", project: projects[0], color: "#10b981" },
  { lat: -39.81448, lng: -73.24505, city: "Valdivia", address: "Sector Hospital Regional, Valdivia", project: projects[2], color: "#f59e0b" },
  { lat: -20.21332, lng: -70.14561, city: "Iquique", address: "Sector industrial norte, Iquique", project: projects[3], color: "#8b5cf6" },
];
const projectBounds = L.latLngBounds(mapMarkers.map((marker) => [marker.lat, marker.lng] as L.LatLngTuple));

function ChileProjectsMap({
  selected,
  onSelect,
}: {
  selected: typeof projects[number] | null;
  onSelect: (project: typeof projects[number] | null) => void;
}) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const markersRef = useRef(new globalThis.Map<string, L.CircleMarker>());
  const selectionReadyRef = useRef(false);

  useEffect(() => {
    if (!containerRef.current || mapRef.current) return;

    const map = L.map(containerRef.current, {
      zoomControl: true,
      minZoom: 3,
      maxZoom: 18,
      worldCopyJump: true,
    });
    mapRef.current = map;

    const tiles = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
      maxZoom: 19,
      attribution: "© OpenStreetMap contributors",
    }).addTo(map);
    let tileErrors = 0;
    let usingFallbackTiles = false;
    tiles.on("tileerror", () => {
      tileErrors += 1;
      if (tileErrors >= 3 && !usingFallbackTiles) {
        usingFallbackTiles = true;
        tiles.setUrl("https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png");
        tiles.redraw();
      }
    });

    map.fitBounds(projectBounds.pad(0.35), { padding: [28, 28], maxZoom: 6 });

    mapMarkers.forEach((markerData) => {
      const marker = L.circleMarker([markerData.lat, markerData.lng], {
        radius: 8,
        color: "#ffffff",
        weight: 2,
        fillColor: markerData.color,
        fillOpacity: 1,
      }).addTo(map);

      const popup = document.createElement("div");
      const title = document.createElement("strong");
      const details = document.createElement("span");
      const address = document.createElement("span");
      const coordinates = document.createElement("code");
      title.textContent = markerData.project.name;
      details.textContent = `${markerData.city} · ${markerData.project.progress}% de avance`;
      address.textContent = markerData.address;
      coordinates.textContent = `${markerData.lat.toFixed(6)}, ${markerData.lng.toFixed(6)}`;
      popup.className = "obratrack-map-popup";
      title.className = "obratrack-map-popup-title";
      details.className = "obratrack-map-popup-detail";
      address.className = "obratrack-map-popup-address";
      coordinates.className = "obratrack-map-popup-coordinates";
      popup.append(title, details, address, coordinates);

      marker.bindPopup(popup, { closeButton: false, offset: [0, -4] });
      marker.bindTooltip(`${markerData.city} · ${markerData.project.progress}%`, {
        direction: "right",
        offset: [10, 0],
        className: "obratrack-map-tooltip",
      });
      marker.on("click", () => onSelect(markerData.project));
      markersRef.current.set(markerData.project.id, marker);
    });

    const syncLocationLabels = () => {
      const showLabels = map.getZoom() >= 9;
      markersRef.current.forEach((marker) => {
        if (showLabels) marker.openTooltip();
        else marker.closeTooltip();
      });
    };
    map.on("zoomend", syncLocationLabels);

    let resizeFrame = 0;
    const refreshMapSize = () => {
      window.cancelAnimationFrame(resizeFrame);
      resizeFrame = window.requestAnimationFrame(() => map.invalidateSize({ pan: false }));
    };
    const resizeObserver = new ResizeObserver(refreshMapSize);
    resizeObserver.observe(containerRef.current);
    refreshMapSize();

    return () => {
      resizeObserver.disconnect();
      window.cancelAnimationFrame(resizeFrame);
      markersRef.current.clear();
      map.remove();
      mapRef.current = null;
      selectionReadyRef.current = false;
    };
  }, [onSelect]);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    if (!selectionReadyRef.current) {
      selectionReadyRef.current = true;
      if (!selected) return;
    }
    markersRef.current.forEach((marker, projectId) => {
      const markerData = mapMarkers.find((item) => item.project.id === projectId);
      if (!markerData) return;
      const active = selected?.id === projectId;
      marker.setRadius(active ? 11 : 8);
      marker.setStyle({
        weight: active ? 3 : 2,
        fillColor: markerData.color,
        color: "#ffffff",
      });
      if (active) {
        marker.openPopup();
        map.stop();
        map.flyTo(marker.getLatLng(), Math.max(map.getZoom(), 13), { duration: 0.7 });
      }
    });
    if (!selected) {
      map.stop();
      map.closePopup();
      map.flyToBounds(projectBounds.pad(0.35), { padding: [28, 28], maxZoom: 6, duration: 0.7 });
    }
  }, [selected]);

  return (
    <div className="relative h-full w-full">
      <div ref={containerRef} className="h-full w-full" aria-label="Mapa interactivo de proyectos en Chile" />
      <button
        onClick={() => onSelect(null)}
        className={`absolute bottom-5 right-3 z-[500] rounded-md border border-slate-300 bg-white/95 px-2.5 py-1.5 text-[10px] font-semibold text-slate-700 shadow-md transition hover:bg-white ${selected ? "opacity-100" : "pointer-events-none opacity-0"}`}
        aria-hidden={!selected}
        tabIndex={selected ? 0 : -1}
      >
        Ver todos los proyectos
      </button>
    </div>
  );
}

function MapView() {
  const [selected, setSelected] = useState<typeof projects[0] | null>(null);

  return (
    <div className="p-3 sm:p-5">
      <div className="mb-4 flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-slate-200">Mapa de Proyectos</h2>
        <span className="rounded-full border border-emerald-500/20 bg-emerald-500/10 px-2.5 py-1 text-[9px] font-medium text-emerald-400">Mapa real de Chile</span>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="relative h-[460px] overflow-hidden rounded-lg border border-border bg-slate-900 lg:col-span-2">
          <ChileProjectsMap selected={selected} onSelect={setSelected} />
        </div>

        <div className="space-y-2.5">
          <h3 className="text-[9px] font-semibold text-slate-600 uppercase tracking-widest mb-3" style={{ fontFamily: MONO }}>Ubicaciones</h3>
          {mapMarkers.map((marker) => {
            const project = marker.project;
            return (
            <div
              key={project.id}
              onClick={() => setSelected(project)}
              className={`rounded-lg border p-3 cursor-pointer transition-all ${selected?.id === project.id ? "border-blue-500/40 bg-blue-600/6" : "border-border hover:border-slate-700"}`}
              style={{ background: selected?.id === project.id ? undefined : "#0f1623" }}
            >
              <div className="flex items-start gap-2.5">
                <div className="w-8 h-8 rounded-md flex items-center justify-center flex-shrink-0" style={{ background: `${marker.color}15`, border: `1px solid ${marker.color}30` }}>
                  <Building2 size={13} style={{ color: marker.color }} />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium text-slate-200 truncate">{project.name}</div>
                  <div className="text-[9px] text-slate-500 mt-0.5">{marker.address}</div>
                  <div className="mt-1 text-[8px] text-slate-700" style={{ fontFamily: MONO }}>{marker.lat.toFixed(6)}, {marker.lng.toFixed(6)}</div>
                  <div className="mt-1.5 h-1 bg-white/6 rounded-full overflow-hidden">
                    <div className="h-full rounded-full" style={{ width: `${project.progress}%`, background: marker.color }} />
                  </div>
                  <div className="mt-1 flex items-center justify-between">
                    <span className="text-[9px] text-slate-700" style={{ fontFamily: MONO }}>{project.progress}% completado</span>
                    <span className="flex items-center gap-1 text-[9px] font-medium text-blue-400"><Crosshair size={9} /> Ver ubicación</span>
                  </div>
                </div>
              </div>
            </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─── Admin ────────────────────────────────────────────────────────────────────
function AdminPanel() {
  const { notify, openDetails, openPrompt } = useUI();
  const [users, setUsers] = useState(adminUsers);
  const [userQuery, setUserQuery] = useState("");
  const visibleUsers = users.filter((user) => `${user.name} ${user.email} ${user.role}`.toLowerCase().includes(userQuery.toLowerCase()));

  const inviteUser = () => openPrompt({
    title: "Invitar usuario",
    label: "Correo electrónico",
    placeholder: "persona@empresa.cl",
    confirmLabel: "Enviar invitación",
    onSubmit: (email) => {
      setUsers((current) => [...current, {
        id: Math.max(...current.map((user) => user.id), 0) + 1,
        name: email.split("@")[0],
        email,
        role: "Trabajador",
        status: "inactivo",
        projects: 0,
        lastLogin: "Invitación pendiente",
      }]);
      notify("Invitación enviada");
    },
  });

  return (
    <div className="p-3 sm:p-5 space-y-5">
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-sm font-semibold text-slate-200">Panel Administrativo</h2>
        <button onClick={inviteUser} className="flex items-center gap-1.5 text-[11px] text-white bg-blue-600 px-2.5 py-1.5 rounded hover:bg-blue-700 transition-colors">
          <Plus size={11} /> Invitar Usuario
        </button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {[
          { label: "Total Usuarios", value: "83", icon: Users, color: "#3b82f6" },
          { label: "Roles Activos", value: "5", icon: Shield, color: "#8b5cf6" },
          { label: "Proyectos", value: "4", icon: Building2, color: "#10b981" },
          { label: "Empresas", value: "7", icon: Globe, color: "#06b6d4" },
        ].map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="rounded-lg border border-border p-3.5" style={{ background: "#0f1623" }}>
              <div className="flex items-center justify-between mb-2">
                <span className="text-[9px] text-slate-600 uppercase tracking-widest" style={{ fontFamily: MONO }}>{stat.label}</span>
                <Icon size={13} style={{ color: stat.color }} />
              </div>
              <div className="text-2xl font-bold text-white">{stat.value}</div>
            </div>
          );
        })}
      </div>

      <div className="rounded-lg border border-border overflow-hidden" style={{ background: "#0f1623" }}>
        <div className="px-4 py-2.5 border-b border-border flex items-center justify-between">
          <span className="text-xs font-semibold text-slate-300">Usuarios del Sistema</span>
          <div className="flex items-center gap-1.5 bg-white/5 border border-border rounded-md px-2.5 py-1">
            <Search size={11} className="text-slate-600" />
            <input value={userQuery} onChange={(event) => setUserQuery(event.target.value)} placeholder="Buscar usuario..." className="bg-transparent text-[11px] text-slate-300 placeholder:text-slate-700 outline-none w-28" />
          </div>
        </div>
        <div className="overflow-x-auto">
        <table className="w-full min-w-[520px]">
          <thead>
            <tr className="border-b border-border">
              {["Usuario", "Rol", "Estado", "Proyectos", "Último acceso", ""].map((h) => (
                <th key={h} className="text-left px-4 py-2.5 text-[9px] font-semibold text-slate-600 uppercase tracking-widest" style={{ fontFamily: MONO }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visibleUsers.map((user) => {
              const initials = user.name.split(" ").map((n) => n[0]).join("").substring(0, 2);
              return (
                <tr key={user.id} className="border-b border-border/40 hover:bg-white/2 transition-colors cursor-pointer">
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-blue-600 to-cyan-500 flex items-center justify-center flex-shrink-0">
                        <span className="text-[10px] font-bold text-white">{initials}</span>
                      </div>
                      <div>
                        <div className="text-xs font-medium text-slate-200">{user.name}</div>
                        <div className="text-[9px] text-slate-600" style={{ fontFamily: MONO }}>{user.email}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-2.5"><span className="text-[10px] text-slate-400">{user.role}</span></td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1.5">
                      <div className={`w-1.5 h-1.5 rounded-full ${user.status === "activo" ? "bg-emerald-400" : "bg-slate-600"}`} />
                      <span className="text-[10px] text-slate-400" style={{ fontFamily: MONO }}>{user.status}</span>
                    </div>
                  </td>
                  <td className="px-4 py-2.5"><span className="text-[10px] text-slate-500" style={{ fontFamily: MONO }}>{user.projects}</span></td>
                  <td className="px-4 py-2.5"><span className="text-[10px] text-slate-600" style={{ fontFamily: MONO }}>{user.lastLogin}</span></td>
                  <td className="px-4 py-2.5">
                    <div className="flex items-center gap-1">
                      <button onClick={() => openDetails(user.name, <div className="space-y-2"><p>{user.email}</p><p>Rol: {user.role}</p><p>Proyectos: {user.projects}</p></div>)} title="Ver usuario" className="p-1 text-slate-700 hover:text-slate-400 rounded transition-colors"><Eye size={12} /></button>
                      <button onClick={() => { setUsers((current) => current.map((item) => item.id === user.id ? { ...item, status: item.status === "activo" ? "inactivo" : "activo" } : item)); notify(`Usuario ${user.status === "activo" ? "desactivado" : "activado"}`); }} title="Cambiar estado" className="p-1 text-slate-700 hover:text-slate-400 rounded transition-colors"><MoreHorizontal size={12} /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        </div>
      </div>
    </div>
  );
}

// ─── App Shell ───────────────────────────────────────────────────────────────
function AppWorkspace() {
  const { perfil, signOut } = useAuth();
  const reduceMotion = useReducedMotion();
  const [activeModule, setActiveModule] = useState<Module>("dashboard");
  const permitidos = ACCESO[perfil!.rol];
  const modulo = permitidos.includes(activeModule) ? activeModule : permitidos[0];
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div
      className="h-screen w-full flex bg-background text-foreground overflow-hidden"
      style={{ fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}
    >
      <Sidebar
        active={modulo}
        permitidos={permitidos}
        nombre={`${perfil!.nombres} ${perfil!.apellidos}`.trim()}
        rolTexto={ROL_LABEL[perfil!.rol]}
        iniciales={`${perfil!.nombres[0] ?? ""}${perfil!.apellidos[0] ?? ""}`.toUpperCase()}
        onLogout={signOut}
        onNavigate={setActiveModule}
        collapsed={collapsed}
        onToggle={() => setCollapsed((c) => !c)}
        mobileOpen={mobileOpen}
        onMobileClose={() => setMobileOpen(false)}
      />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <TopBar module={modulo} onMenuToggle={() => setMobileOpen((o) => !o)} onNavigate={setActiveModule} />
        <main className="flex-1 overflow-y-auto overflow-x-hidden" style={{ scrollbarWidth: "thin", scrollbarColor: "rgba(255,255,255,0.08) transparent" }}>
          <AnimatePresence mode="wait" initial={false}>
            <motion.div
              key={modulo}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={reduceMotion ? { duration: 0.01 } : { duration: 0.28, ease: EASE_OUT }}
              className="min-h-full"
            >
              {modulo === "dashboard" && <Dashboard />}
              {modulo === "bim" && <BIMViewer />}
              {modulo === "planning" && <Planning />}
              {modulo === "control" && <ControlCenter />}
              {modulo === "reports" && <Reports />}
              {modulo === "admin" && <AdminPanel />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

function AppShell() {
  return (
    <UiProvider>
      <AppWorkspace />
    </UiProvider>
  );
}

function StartupSplash({ reduceMotion }: { reduceMotion: boolean }) {
  return (
    <motion.div
      className="fixed inset-0 z-[200] flex items-center justify-center overflow-hidden bg-[#070b12]"
      initial={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: reduceMotion ? 0.01 : 0.28, ease: EASE_OUT }}
    >
      {!reduceMotion && (
        <>
          <motion.div
            className="absolute h-56 w-56 rounded-full border border-blue-500/15"
            initial={{ scale: 0.72, opacity: 0 }}
            animate={{ scale: 1.12, opacity: [0, 0.9, 0] }}
            transition={{ duration: 1.05, ease: EASE_OUT }}
          />
          <motion.div
            className="absolute h-40 w-40 rounded-full bg-blue-500/5 blur-2xl"
            initial={{ scale: 0.7, opacity: 0 }}
            animate={{ scale: 1.25, opacity: [0, 1, 0.35] }}
            transition={{ duration: 1, ease: EASE_OUT }}
          />
        </>
      )}
      <motion.div
        className="relative flex flex-col items-center"
        initial={reduceMotion ? { opacity: 0 } : { opacity: 0, y: 10, scale: 0.94 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={reduceMotion ? { duration: 0.01 } : SPRING_SNAPPY}
      >
        <img src={startupLogo} alt="ObraTrack — Control y Planificación" className="h-auto w-36 object-contain" />
        <div className="mt-5 h-0.5 w-24 overflow-hidden rounded-full bg-white/10">
          <motion.div
            className="h-full origin-left rounded-full bg-gradient-to-r from-cyan-400 to-blue-500"
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: reduceMotion ? 0.01 : 0.85, delay: reduceMotion ? 0 : 0.12, ease: EASE_OUT }}
          />
        </div>
      </motion.div>
    </motion.div>
  );
}

function Gate() {
  const { loading, perfil } = useAuth();
  const reduceMotion = useReducedMotion();
  const [showStartup, setShowStartup] = useState(true);

  useEffect(() => {
    const timer = window.setTimeout(() => setShowStartup(false), reduceMotion ? 250 : 1150);
    return () => window.clearTimeout(timer);
  }, [reduceMotion]);

  return (
    <>
      {loading
        ? <div className="h-screen w-full bg-background flex items-center justify-center text-sm text-slate-500">Cargando…</div>
        : perfil ? <AppShell /> : <AuthScreen />
      }
      <AnimatePresence>
        {showStartup && <StartupSplash reduceMotion={Boolean(reduceMotion)} />}
      </AnimatePresence>
    </>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <Gate />
    </AuthProvider>
  );
}
