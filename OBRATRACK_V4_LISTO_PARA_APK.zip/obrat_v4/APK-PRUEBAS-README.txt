OBRATRACK V4 - GENERAR APK DE PRUEBAS

El proyecto ya incluye Android/Capacitor y el workflow:
.github/workflows/android-apk.yml

Para generar el APK en GitHub:
1. Sube el contenido de esta carpeta a un repositorio GitHub (rama main).
2. En GitHub abre Actions.
3. Selecciona "Build Android APK" y pulsa "Run workflow" (o espera al push a main).
4. Cuando termine correctamente, abre la ejecución y descarga el artefacto "OBRATRACK-debug-apk".
5. Descomprime el artefacto y copia app-debug.apk al teléfono Android.
6. Abre el APK en el teléfono y autoriza la instalación desde esa fuente si Android lo solicita.

CONFIGURACIÓN BACKEND:
El proyecto puede compilar sin credenciales Supabase y abrirá en modo demostración con datos de ejemplo.
Para conectar el backend real, configura en GitHub Settings > Secrets and variables > Actions:
- VITE_SUPABASE_URL
- VITE_SUPABASE_ANON_KEY

No uses una service_role key en la app móvil. La clave anon/publicable es la adecuada junto con políticas RLS.

Este APK debug es para pruebas, no es una versión firmada para publicar en Google Play.
