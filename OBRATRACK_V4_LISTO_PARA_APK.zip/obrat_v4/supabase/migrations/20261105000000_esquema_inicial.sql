-- obratrack · esquema v2 (PostgreSQL / Supabase). Reemplaza a obratrack_esquema.sql
-- Cambios: 5 roles (los de la app), el rol lo define la invitación (no se elige al registrarse),
-- el código se canjea dentro del registro (funciona aunque haya confirmación por correo)
-- y los usuarios no pueden cambiarse el rol a sí mismos.

create extension if not exists pgcrypto;

create type rol_usuario   as enum ('administrador','director_proyecto','supervisor','trabajador','cliente');
create type estado_cuenta as enum ('activo','suspendido');
create type estado_obra   as enum ('planificacion','en_ejecucion','pausada','terminada');

create table empresas (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  rut text unique,
  creada_en timestamptz not null default now()
);

create table perfiles (
  id uuid primary key references auth.users(id) on delete cascade,
  empresa_id uuid references empresas(id) on delete set null,
  rol rol_usuario not null,
  nombres text not null,
  apellidos text not null,
  rut text not null unique check (rut ~ '^[0-9]{7,8}-[0-9K]$'),
  telefono text,
  cargo text,
  oficio text,
  estado estado_cuenta not null default 'activo',
  creado_en timestamptz not null default now()
);

create table obras (
  id uuid primary key default gen_random_uuid(),
  empresa_id uuid not null references empresas(id) on delete cascade,
  nombre text not null,
  cliente text,
  direccion text,
  comuna text,
  latitud numeric, longitud numeric,
  estado estado_obra not null default 'planificacion',
  avance int not null default 0 check (avance between 0 and 100),
  inicio date, termino_estimado date,
  creada_en timestamptz not null default now()
);

create table obra_miembros (
  obra_id uuid not null references obras(id) on delete cascade,
  perfil_id uuid not null references perfiles(id) on delete cascade,
  rol rol_usuario not null,
  desde date not null default current_date,
  primary key (obra_id, perfil_id)
);

-- El código fija empresa, rol y (opcionalmente) la obra a la que entra quien lo use
create table invitaciones (
  codigo text primary key default upper(substr(encode(gen_random_bytes(5), 'hex'), 1, 8)),
  empresa_id uuid not null references empresas(id) on delete cascade,
  obra_id uuid references obras(id) on delete cascade,
  rol rol_usuario not null default 'trabajador',
  creada_por uuid not null references perfiles(id),
  usos_max int not null default 50,
  usos int not null default 0,
  expira_en timestamptz not null default now() + interval '30 days'
);

create index on obra_miembros (perfil_id);
create index on obras (empresa_id);

-- Auxiliares de seguridad
create function mi_empresa() returns uuid language sql stable security definer set search_path = public
as $$ select empresa_id from perfiles where id = auth.uid() $$;

create function mi_rol() returns rol_usuario language sql stable security definer set search_path = public
as $$ select rol from perfiles where id = auth.uid() $$;

create function gestiona_empresa(p_empresa uuid) returns boolean language sql stable security definer set search_path = public
as $$ select p_empresa = mi_empresa() and mi_rol() in ('administrador','director_proyecto') $$;

create function pertenece_a_obra(p_obra uuid) returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from obra_miembros where obra_id = p_obra and perfil_id = auth.uid()) $$;

-- Permite a la pantalla de registro comprobar un código antes de crear la cuenta
create function validar_invitacion(p_codigo text) returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from invitaciones where codigo = upper(p_codigo) and expira_en > now() and usos < usos_max) $$;
grant execute on function validar_invitacion(text) to anon, authenticated;

-- Crea el perfil al registrarse: con código entra a una empresa con el rol de la invitación;
-- sin código crea una empresa nueva y queda como administrador.
create function crear_perfil_al_registrar() returns trigger language plpgsql security definer set search_path = public as $$
declare
  m jsonb := new.raw_user_meta_data;
  inv invitaciones;
  emp uuid; rol_nuevo rol_usuario;
begin
  if coalesce(m->>'codigo','') <> '' then
    select * into inv from invitaciones
     where codigo = upper(m->>'codigo') and expira_en > now() and usos < usos_max for update;
    if not found then raise exception 'Código de invitación inválido o vencido'; end if;
    emp := inv.empresa_id; rol_nuevo := inv.rol;
  elsif coalesce(m->>'empresa','') <> '' then
    insert into empresas (nombre) values (m->>'empresa') returning id into emp;
    rol_nuevo := 'administrador';
  else
    raise exception 'Falta el nombre de la empresa o el código de invitación';
  end if;

  insert into perfiles (id, empresa_id, rol, nombres, apellidos, rut, telefono, cargo, oficio)
  values (new.id, emp, rol_nuevo, m->>'nombres', m->>'apellidos', upper(m->>'rut'),
          m->>'telefono', m->>'cargo', m->>'oficio');

  if inv.codigo is not null then
    if inv.obra_id is not null then
      insert into obra_miembros (obra_id, perfil_id, rol) values (inv.obra_id, new.id, rol_nuevo);
    end if;
    update invitaciones set usos = usos + 1 where codigo = inv.codigo;
  end if;
  return new;
end $$;

create trigger al_registrar after insert on auth.users
for each row execute function crear_perfil_al_registrar();

-- Solo un administrador cambia roles
create function cambiar_rol(p_perfil uuid, p_rol rol_usuario) returns void
language plpgsql security definer set search_path = public as $$
begin
  if mi_rol() <> 'administrador' then raise exception 'Solo un administrador puede cambiar roles'; end if;
  update perfiles set rol = p_rol where id = p_perfil and empresa_id = mi_empresa();
end $$;

-- Seguridad por filas
alter table empresas      enable row level security;
alter table perfiles      enable row level security;
alter table obras         enable row level security;
alter table obra_miembros enable row level security;
alter table invitaciones  enable row level security;

create policy "mi empresa" on empresas for select using (id = mi_empresa());

create policy "mi perfil" on perfiles for select using (id = auth.uid());
create policy "equipo de mi empresa" on perfiles for select using (gestiona_empresa(empresa_id));
create policy "editar mi perfil" on perfiles for update using (id = auth.uid());
-- Cada usuario solo puede modificar estos campos de su propio perfil (no el rol ni la empresa)
revoke update on perfiles from authenticated;
grant update (nombres, apellidos, telefono, cargo, oficio) on perfiles to authenticated;

create policy "ver obras" on obras for select using (
  gestiona_empresa(empresa_id) or (empresa_id = mi_empresa() and pertenece_a_obra(id)));
create policy "gestionar obras" on obras for all using (gestiona_empresa(empresa_id)) with check (gestiona_empresa(empresa_id));

create policy "ver membresías" on obra_miembros for select using (
  perfil_id = auth.uid() or exists (select 1 from obras o where o.id = obra_id and gestiona_empresa(o.empresa_id)));
create policy "gestionar miembros" on obra_miembros for all
  using (exists (select 1 from obras o where o.id = obra_id and gestiona_empresa(o.empresa_id)))
  with check (exists (select 1 from obras o where o.id = obra_id and gestiona_empresa(o.empresa_id)));

-- Un director no puede crear invitaciones de administrador
create policy "gestionar invitaciones" on invitaciones for all
  using (gestiona_empresa(empresa_id))
  with check (gestiona_empresa(empresa_id) and (mi_rol() = 'administrador' or rol <> 'administrador'));
