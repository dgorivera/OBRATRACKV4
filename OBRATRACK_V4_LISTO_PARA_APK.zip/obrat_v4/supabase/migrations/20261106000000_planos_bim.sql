-- Planos BIM y documentos técnicos almacenados de forma privada por obra.

create type estado_plano_bim as enum ('procesando', 'listo', 'error');

create table planos_bim (
  id uuid primary key default gen_random_uuid(),
  obra_id uuid not null references obras(id) on delete cascade,
  nombre text not null,
  storage_path text not null unique,
  tipo text not null check (tipo in ('IFC', 'DWG', 'DXF', 'PDF', 'RVT', 'NWD', 'NWC')),
  tamano bigint not null check (tamano > 0 and tamano <= 104857600),
  estado estado_plano_bim not null default 'listo',
  version text not null default '1.0',
  subido_por uuid not null references perfiles(id),
  creado_en timestamptz not null default now()
);

create index planos_bim_obra_creado_idx on planos_bim (obra_id, creado_en desc);

alter table planos_bim enable row level security;

create policy "ver planos de obras autorizadas" on planos_bim for select using (
  exists (
    select 1 from obras o
    where o.id = obra_id
      and (gestiona_empresa(o.empresa_id) or (o.empresa_id = mi_empresa() and pertenece_a_obra(o.id)))
  )
);

create policy "cargar planos en obras autorizadas" on planos_bim for insert with check (
  subido_por = auth.uid()
  and mi_rol() <> 'cliente'
  and exists (
    select 1 from obras o
    where o.id = obra_id
      and (gestiona_empresa(o.empresa_id) or (o.empresa_id = mi_empresa() and pertenece_a_obra(o.id)))
  )
);

create policy "actualizar planos propios o gestionados" on planos_bim for update
using (
  subido_por = auth.uid()
  or exists (select 1 from obras o where o.id = obra_id and gestiona_empresa(o.empresa_id))
)
with check (
  subido_por = auth.uid()
  or exists (select 1 from obras o where o.id = obra_id and gestiona_empresa(o.empresa_id))
);

create policy "eliminar planos propios o gestionados" on planos_bim for delete using (
  subido_por = auth.uid()
  or exists (select 1 from obras o where o.id = obra_id and gestiona_empresa(o.empresa_id))
);

insert into storage.buckets (id, name, public, file_size_limit)
values ('planos-bim', 'planos-bim', false, 104857600)
on conflict (id) do update
set public = excluded.public, file_size_limit = excluded.file_size_limit;

create policy "leer archivos de planos autorizados" on storage.objects for select using (
  bucket_id = 'planos-bim'
  and exists (
    select 1 from obras o
    where o.id::text = (storage.foldername(name))[1]
      and (gestiona_empresa(o.empresa_id) or (o.empresa_id = mi_empresa() and pertenece_a_obra(o.id)))
  )
);

create policy "cargar archivos de planos autorizados" on storage.objects for insert with check (
  bucket_id = 'planos-bim'
  and mi_rol() <> 'cliente'
  and exists (
    select 1 from obras o
    where o.id::text = (storage.foldername(name))[1]
      and (gestiona_empresa(o.empresa_id) or (o.empresa_id = mi_empresa() and pertenece_a_obra(o.id)))
  )
);

create policy "eliminar archivos de planos propios o gestionados" on storage.objects for delete using (
  bucket_id = 'planos-bim'
  and exists (
    select 1
    from planos_bim p
    join obras o on o.id = p.obra_id
    where p.storage_path = name
      and (p.subido_por = auth.uid() or gestiona_empresa(o.empresa_id))
  )
);
